import os
import torch


class GlobalConfig:
    def __init__(self):
        # Basic paths. This keeps the original project layout:
        # project/
        #   config/global_config_variables.py
        #   data/all_data_water_yh.csv
        #   outputs_all_variables/
        self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.data_path = os.path.join(self.base_dir, "data", "all_data_water_yh.csv")
        self.output_dir = os.path.join(self.base_dir, "outputs_all_variables")

        # All-variable forecasting task.
        self.task_name = "all_variables"
        self.time_col = "_time"
        self.exclude_cols = []  # Add columns here if they should not be used as variables.
        self.target_col = None  # Kept for backward compatibility only.

        self.seq_len = 96
        self.pred_len = 96
        self.eval_steps = [1, 6, 8, 12, 24, 48, 96]

        # Data processing.
        self.use_all_variables = True
        self.save_correlation_plot = True
        self.max_corr_plot_vars = 40

        # Data split ratios.
        self.train_ratio = 0.7
        self.val_ratio = 0.1
        self.test_ratio = 0.2

        # Training.
        self.batch_size = 32
        self.epochs = 80
        self.patience = 10
        self.learning_rate = 5e-4
        self.weight_decay = 1e-4
        self.loss_name = "huber"
        self.huber_delta = 1.0

        # Runtime benchmark.
        self.runtime_batch_size = 64
        self.runtime_warmup_batches = 5
        self.runtime_repeats = 5

        # Misc.
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.seed = 42

    def init_output_dirs(self, model_name: str = None):
        base = self.output_dir if model_name is None else os.path.join(self.output_dir, model_name)
        for sub in ["checkpoints", "figures", "predictions", "logs"]:
            os.makedirs(os.path.join(base, sub), exist_ok=True)
        return base
