import os
import sys
import time
import random
import argparse
import math
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

from config.global_config_variables import GlobalConfig
from src.data_process_variables import DataProcessor, TimeSeriesDataset
from src.utils_variables import inverse_transform_window

from models.dlinear import Model as DLinearModel
from models.mixlinear import Model as MixLinearModel
from models.sparsetsf import SparseTSF
from models.patchtst import Model as PatchTST
from models.itransformer import Model as ITransformer
from models.tsf_resonator import TSFResonator


# ============================================================
# 1. Basic utilities
# ============================================================
def set_seed(seed=2025, deterministic=True):
    # Set all relevant random seeds for repeated-run experiments.
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if deterministic:
        # Improves reproducibility. Some CUDA operations may still have minor
        # nondeterminism depending on PyTorch/CUDA versions.
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        try:
            torch.use_deterministic_algorithms(True, warn_only=True)
        except TypeError:
            try:
                torch.use_deterministic_algorithms(True)
            except Exception:
                pass
        except Exception:
            pass


def sync_device(device):
    if torch.cuda.is_available() and device.type == "cuda":
        torch.cuda.synchronize(device)


def count_params(model, trainable_only=False):
    if trainable_only:
        return int(sum(p.numel() for p in model.parameters() if p.requires_grad))
    return int(sum(p.numel() for p in model.parameters()))


def set_journal_style():
    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 9,
        "axes.labelsize": 10,
        "axes.titlesize": 10,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
        "xtick.major.size": 3,
        "ytick.major.size": 3,
        "lines.linewidth": 1.6,
        "lines.markersize": 4.0,
        "figure.dpi": 300,
        "savefig.dpi": 600,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.03,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })


def visual_style():
    colors = {
        "Persistence": "#7F7F7F",
        "DLinear": "#4C72B0",
        "SparseTSF": "#55A868",
        "MixLinear": "#DD8452",
        "PatchTST": "#8172B3",
        "iTransformer": "#64B5CD",
        "TSF-Resonator": "#C44E52",
    }
    hatches = {
        "Persistence": "",
        "DLinear": "xx",
        "SparseTSF": "\\\\",
        "MixLinear": "//",
        "PatchTST": "..",
        "iTransformer": "++",
        "TSF-Resonator": "oo",
    }
    markers = {
        "Persistence": "X",
        "DLinear": "o",
        "SparseTSF": "^",
        "MixLinear": "s",
        "PatchTST": "P",
        "iTransformer": "v",
        "TSF-Resonator": "D",
    }
    linestyles = {
        "Persistence": (0, (1, 1)),
        "DLinear": "-",
        "SparseTSF": "--",
        "MixLinear": "-.",
        "PatchTST": ":",
        "iTransformer": (0, (3, 1, 1, 1)),
        "TSF-Resonator": "-",
    }
    return colors, hatches, markers, linestyles



# ============================================================
# 2. Persistence baseline
# ============================================================
def canonical_model_name(model_name):
    """
    Normalize common spellings/aliases of the persistence baseline.

    The canonical name used in logs, figures, and output files is "Persistence".
    The misspelling "Persistance" is accepted for command-line convenience.
    """
    name = str(model_name).strip()
    key = name.lower().replace("-", "_").replace(" ", "_")
    persistence_aliases = {
        "persistence",
        "persistance",
        "naive",
        "naive_persistence",
        "last_value",
        "last_value_baseline",
    }
    if key in persistence_aliases:
        return "Persistence"
    return name


def deduplicate_preserve_order(items):
    seen = set()
    out = []
    for item in items:
        if item not in seen:
            out.append(item)
            seen.add(item)
    return out


class PersistenceModel(nn.Module):
    """
    Last-observation-carried-forward baseline.

    For each input window x with shape [batch, seq_len, num_vars], the model
    repeats the last observed value of every variable for pred_len steps and
    returns a tensor with shape [batch, pred_len, num_vars]. The evaluation
    pipeline then extracts the target column exactly as it does for learned
    multivariate forecasters.
    """
    def __init__(self, pred_len, target_idx=None):
        super().__init__()
        self.pred_len = int(pred_len)
        self.target_idx = target_idx

    def forward(self, x):
        if x.ndim != 3:
            raise ValueError(f"PersistenceModel expects x with shape [B, L, C], got {tuple(x.shape)}")
        return x[:, -1:, :].repeat(1, self.pred_len, 1)


# ============================================================
# 2. Model builder
# ============================================================
def build_model(model_name, cfg, num_vars):
    model_name = canonical_model_name(model_name)

    if model_name == "Persistence":
        return PersistenceModel(pred_len=cfg.pred_len)

    if model_name == "DLinear":
        class DLinearConfig:
            def __init__(self, seq_len, pred_len, enc_in):
                self.seq_len = seq_len
                self.pred_len = pred_len
                self.enc_in = enc_in
                self.individual = False
                self.decomp_kernel = 25
        return DLinearModel(DLinearConfig(cfg.seq_len, cfg.pred_len, num_vars))

    if model_name == "MixLinear":
        class MixConfig:
            def __init__(self, seq_len, pred_len, enc_in):
                self.seq_len = seq_len
                self.pred_len = pred_len
                self.enc_in = enc_in
                self.period_len = 12
                self.lpf = 6
                self.alpha = 0.5
        return MixLinearModel(MixConfig(cfg.seq_len, cfg.pred_len, num_vars))

    if model_name == "SparseTSF":
        return SparseTSF(num_vars=num_vars, seq_len=cfg.seq_len, pred_len=cfg.pred_len, w=12)

    if model_name == "PatchTST":
        class PatchConfig:
            def __init__(self, seq_len, pred_len, enc_in):
                self.enc_in = enc_in
                self.seq_len = seq_len
                self.pred_len = pred_len
                self.e_layers = 3
                self.n_heads = 4
                self.d_model = 64
                self.d_ff = 128
                self.dropout = 0.3
                self.fc_dropout = 0.1
                self.head_dropout = 0.0
                self.individual = False
                self.patch_len = 16
                self.stride = 8
                self.padding_patch = "end"
                self.revin = True
                self.affine = True
                self.subtract_last = False
                self.decomposition = False
                self.kernel_size = 25
        return PatchTST(PatchConfig(cfg.seq_len, cfg.pred_len, num_vars))

    if model_name == "iTransformer":
        class ITConfig:
            def __init__(self, seq_len, pred_len, enc_in):
                self.seq_len = seq_len
                self.pred_len = pred_len
                self.enc_in = enc_in
                self.d_model = 64
                self.n_heads = 4
                self.e_layers = 2
                self.d_ff = 128
                self.dropout = 0.3
                self.activation = "gelu"
                self.output_attention = False
                self.use_norm = True
                self.embed = "fixed"
                self.freq = "h"
                self.factor = 1
                self.padding = 0
                self.features = "M"
                self.label_len = pred_len // 2
        return ITransformer(ITConfig(cfg.seq_len, cfg.pred_len, num_vars))

    if model_name == "TSF-Resonator":
        model = TSFResonator(
            num_vars=num_vars,
            seq_len=cfg.seq_len,
            pred_len=cfg.pred_len,
            trend_scales=[3, 7, 15],
            d_res=16,
            dropout=0.1,
        )
        model.target_idx = -1
        return model

    raise ValueError(f"Unknown model: {model_name}")


# ============================================================
# 3. Forward and metrics
# ============================================================
def forward_model(model, model_name, x, cfg, device):
    if model_name == "iTransformer":
        bsz, seq_len, _ = x.shape
        x_mark = torch.zeros(bsz, seq_len, 4, device=device)
        y_mark = torch.zeros(bsz, cfg.pred_len, 4, device=device)
        return model(x, x_mark, None, y_mark)
    return model(x)


def extract_target_prediction(pred, model_name, target_idx):
    if model_name == "TSF-Resonator":
        if pred.ndim == 2:
            return pred
        if pred.ndim == 3:
            return pred[:, :, target_idx]
        raise ValueError(f"Unexpected TSF-Resonator output shape: {pred.shape}")
    if pred.ndim == 3:
        return pred[:, :, target_idx]
    if pred.ndim == 2:
        return pred
    raise ValueError(f"Unexpected output shape: {pred.shape}")


def compute_metrics(y_true, y_pred):
    y_true = np.asarray(y_true).reshape(-1)
    y_pred = np.asarray(y_pred).reshape(-1)
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    y_true, y_pred = y_true[mask], y_pred[mask]
    if y_true.size == 0:
        return {"MSE": np.nan, "MAE": np.nan, "RMSE": np.nan, "R2": np.nan}
    err = y_true - y_pred
    mse = np.mean(err ** 2)
    mae = np.mean(np.abs(err))
    rmse = np.sqrt(mse)
    ss_res = np.sum(err ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    r2 = np.nan if ss_tot == 0 else 1.0 - ss_res / ss_tot
    return {"MSE": float(mse), "MAE": float(mae), "RMSE": float(rmse), "R2": float(r2)}


def compute_stepwise_metrics(y_true, y_pred):
    rows = []
    for step in range(y_true.shape[1]):
        m = compute_metrics(y_true[:, step], y_pred[:, step])
        m["Step"] = step + 1
        rows.append(m)
    return pd.DataFrame(rows, columns=["Step", "MSE", "MAE", "RMSE", "R2"])


def get_model_input_variable_names(processor, data_scaled=None, num_vars=None):
    """
    Try to recover the variable names used as model inputs.

    This is intentionally defensive because different DataProcessor
    implementations expose column names with different attribute names.
    If no names are available, it falls back to x0, x1, ...
    """
    candidate_attrs = [
        "input_cols",
        "input_columns",
        "feature_cols",
        "feature_columns",
        "selected_features",
        "selected_cols",
        "selected_columns",
        "all_feature_cols",
        "numeric_cols",
        "data_columns",
        "columns",
    ]

    for attr in candidate_attrs:
        if not hasattr(processor, attr):
            continue
        cols = getattr(processor, attr)
        if cols is None:
            continue
        try:
            cols = list(cols)
        except TypeError:
            continue

        if num_vars is None or len(cols) == num_vars:
            return [str(c) for c in cols]

        # Some processors may keep a longer original column list.
        # In that case, use the leading num_vars names as a best-effort fallback.
        if num_vars is not None and len(cols) > num_vars:
            return [str(c) for c in cols[:num_vars]]

    # Common fallbacks if the processor stores a DataFrame.
    for attr in ["df", "data", "raw_data", "processed_data"]:
        obj = getattr(processor, attr, None)
        if hasattr(obj, "columns"):
            cols = list(obj.columns)
            if num_vars is None or len(cols) == num_vars:
                return [str(c) for c in cols]
            if num_vars is not None and len(cols) > num_vars:
                return [str(c) for c in cols[:num_vars]]

    # If prepare_data returns a pandas DataFrame, use its columns.
    if hasattr(data_scaled, "columns"):
        cols = list(data_scaled.columns)
        if num_vars is None or len(cols) == num_vars:
            return [str(c) for c in cols]
        if num_vars is not None and len(cols) > num_vars:
            return [str(c) for c in cols[:num_vars]]

    if num_vars is None and hasattr(data_scaled, "shape") and len(data_scaled.shape) >= 2:
        num_vars = int(data_scaled.shape[1])

    return [f"x{i}" for i in range(int(num_vars or 0))]


def print_model_input_variables(processor, cfg, target_idx, num_vars, data_scaled=None, indent="  "):
    """Print model input variable names and mark the target-history column."""
    input_vars = get_model_input_variable_names(
        processor=processor,
        data_scaled=data_scaled,
        num_vars=num_vars,
    )

    print(f"{indent}Model input variables ({len(input_vars)} total):")
    for i, name in enumerate(input_vars):
        marker = "  <-- target history / forecast target" if i == target_idx else ""
        print(f"{indent}  [{i:03d}] {name}{marker}")

    print(
        f"{indent}Target column: {cfg.target_col} | "
        f"target_idx={target_idx} | num_vars={num_vars}"
    )


# ============================================================
# 4. Runtime benchmark
# ============================================================
def benchmark_inference(model, model_name, runtime_loader, cfg, device, warmup_batches=5, repeat=5):
    model.eval()

    with torch.no_grad():
        for i, (x, _) in enumerate(runtime_loader):
            if i >= warmup_batches:
                break
            x = x.to(device)
            _ = forward_model(model, model_name, x, cfg, device)

    sync_device(device)

    total_time = 0.0
    total_batches = 0
    total_windows = 0

    with torch.no_grad():
        for _ in range(repeat):
            sync_device(device)
            start = time.perf_counter()
            nb, nw = 0, 0

            for x, _ in runtime_loader:
                x = x.to(device)
                _ = forward_model(model, model_name, x, cfg, device)
                nb += 1
                nw += int(x.shape[0])

            sync_device(device)
            end = time.perf_counter()

            total_time += end - start
            total_batches += nb
            total_windows += nw

    return {
        "InferenceLatencyMsPerWindow": float(1000.0 * total_time / max(total_windows, 1)),
        "InferenceLatencyMsPerBatch": float(1000.0 * total_time / max(total_batches, 1)),
        "InferenceThroughputWindowsPerSec": float(total_windows / max(total_time, 1e-12)),
        "RuntimeBenchmarkBatches": int(total_batches),
        "RuntimeBenchmarkWindows": int(total_windows),
    }


# ============================================================
# 5. Training, evaluation, and runtime recording
# ============================================================
def evaluate_model_without_training(model, test_loader, runtime_loader, cfg, device,
                                    target_idx, num_vars, scaler, model_name):
    """
    Evaluate a deterministic/no-training baseline such as Persistence.

    The returned objects follow the same contract as train_and_evaluate so the
    downstream logging, plotting, prediction export, and statistical summary
    code can remain unchanged.
    """
    if hasattr(model, "target_idx"):
        model.target_idx = target_idx

    if torch.cuda.is_available() and device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)

    model.eval()
    preds, actuals = [], []
    with torch.no_grad():
        for x, y in test_loader:
            x = x.to(device)
            pred = forward_model(model, model_name, x, cfg, device)
            pred_target = extract_target_prediction(pred, model_name, target_idx)
            preds.append(pred_target.cpu().numpy())
            actuals.append(y[:, :, target_idx].cpu().numpy())

    preds = np.concatenate(preds, axis=0)
    actuals = np.concatenate(actuals, axis=0)

    inv_pred, inv_act = inverse_transform_window(preds, actuals, scaler, target_idx, num_vars)

    overall_metrics = compute_metrics(inv_act, inv_pred)
    step_metrics = compute_stepwise_metrics(inv_act, inv_pred)

    inference_runtime = benchmark_inference(
        model=model,
        model_name=model_name,
        runtime_loader=runtime_loader,
        cfg=cfg,
        device=device,
        warmup_batches=cfg.runtime_warmup_batches,
        repeat=cfg.runtime_repeats,
    )

    peak_gpu_memory = np.nan
    if torch.cuda.is_available() and device.type == "cuda":
        peak_gpu_memory = torch.cuda.max_memory_allocated(device) / (1024 ** 2)

    history = {
        "train_loss": [],
        "val_loss": [],
        "train_epoch_time_sec": [],
        "val_epoch_time_sec": [],
        "epoch_time_sec": [],
    }

    runtime_metrics = {
        "TotalParams": count_params(model, trainable_only=False),
        "TrainableParams": count_params(model, trainable_only=True),
        "ActualEpochs": 0,
        "BestEpoch": 0,
        "TotalFitTimeSec": 0.0,
        "AvgEpochTimeSec": 0.0,
        "AvgTrainEpochTimeSec": 0.0,
        "AvgValEpochTimeSec": 0.0,
        "PeakGpuMemoryMB": float(peak_gpu_memory) if np.isfinite(peak_gpu_memory) else np.nan,
    }
    runtime_metrics.update(inference_runtime)

    return overall_metrics, step_metrics, inv_pred, inv_act, history, runtime_metrics


def train_and_evaluate(model, train_loader, val_loader, test_loader, runtime_loader,
                       cfg, device, target_idx, num_vars, scaler, model_name, seed=None):
    model_name = canonical_model_name(model_name)

    if hasattr(model, "target_idx"):
        model.target_idx = target_idx

    if model_name == "Persistence":
        return evaluate_model_without_training(
            model=model,
            test_loader=test_loader,
            runtime_loader=runtime_loader,
            cfg=cfg,
            device=device,
            target_idx=target_idx,
            num_vars=num_vars,
            scaler=scaler,
            model_name=model_name,
        )

    criterion = nn.HuberLoss(delta=cfg.huber_delta) if cfg.loss_name == "huber" else nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", factor=0.5, patience=3)

    safe_target = cfg.target_col.replace(" ", "_").replace("/", "_")
    ckpt_dir = os.path.join(cfg.output_dir, "checkpoints")
    os.makedirs(ckpt_dir, exist_ok=True)
    seed_tag = f"_seed{seed}" if seed is not None else ""
    ckpt_path = os.path.join(ckpt_dir, f"best_{model_name}_{safe_target}_pred{cfg.pred_len}{seed_tag}.pth")

    if torch.cuda.is_available() and device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)

    history = {
        "train_loss": [],
        "val_loss": [],
        "train_epoch_time_sec": [],
        "val_epoch_time_sec": [],
        "epoch_time_sec": [],
    }

    best_val = float("inf")
    best_epoch = -1
    early_stop = 0

    sync_device(device)
    total_start = time.perf_counter()

    for epoch in range(cfg.epochs):
        epoch_start = time.perf_counter()

        model.train()
        train_losses = []
        sync_device(device)
        train_start = time.perf_counter()

        for x, y in train_loader:
            x = x.to(device)
            y = y.to(device)
            pred = forward_model(model, model_name, x, cfg, device)
            pred_target = extract_target_prediction(pred, model_name, target_idx)
            loss = criterion(pred_target, y[:, :, target_idx])

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            train_losses.append(loss.item())

        sync_device(device)
        train_end = time.perf_counter()

        model.eval()
        val_losses = []
        sync_device(device)
        val_start = time.perf_counter()

        with torch.no_grad():
            for x, y in val_loader:
                x = x.to(device)
                y = y.to(device)
                pred = forward_model(model, model_name, x, cfg, device)
                pred_target = extract_target_prediction(pred, model_name, target_idx)
                loss = criterion(pred_target, y[:, :, target_idx])
                val_losses.append(loss.item())

        sync_device(device)
        val_end = time.perf_counter()

        train_loss = float(np.mean(train_losses)) if train_losses else np.nan
        val_loss = float(np.mean(val_losses)) if val_losses else np.nan
        scheduler.step(val_loss)

        epoch_end = time.perf_counter()

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["train_epoch_time_sec"].append(float(train_end - train_start))
        history["val_epoch_time_sec"].append(float(val_end - val_start))
        history["epoch_time_sec"].append(float(epoch_end - epoch_start))

        print(
            f"    Epoch {epoch + 1:03d}/{cfg.epochs} | "
            f"train={train_loss:.6f} | val={val_loss:.6f} | "
            f"time={epoch_end - epoch_start:.2f}s"
        )

        if np.isfinite(val_loss) and val_loss < best_val:
            best_val = val_loss
            best_epoch = epoch + 1
            early_stop = 0
            torch.save(model.state_dict(), ckpt_path)
        else:
            early_stop += 1
            if early_stop >= cfg.patience:
                print(f"    Early stopping at epoch {epoch + 1}. Best val={best_val:.6f}")
                break

    sync_device(device)
    total_end = time.perf_counter()
    total_fit_time = total_end - total_start
    actual_epochs = len(history["train_loss"])

    if not os.path.exists(ckpt_path):
        torch.save(model.state_dict(), ckpt_path)
        best_epoch = actual_epochs

    model.load_state_dict(torch.load(ckpt_path, map_location=device))
    model.eval()

    preds, actuals = [], []
    with torch.no_grad():
        for x, y in test_loader:
            x = x.to(device)
            pred = forward_model(model, model_name, x, cfg, device)
            pred_target = extract_target_prediction(pred, model_name, target_idx)
            preds.append(pred_target.cpu().numpy())
            actuals.append(y[:, :, target_idx].cpu().numpy())

    preds = np.concatenate(preds, axis=0)
    actuals = np.concatenate(actuals, axis=0)

    inv_pred, inv_act = inverse_transform_window(preds, actuals, scaler, target_idx, num_vars)

    overall_metrics = compute_metrics(inv_act, inv_pred)
    step_metrics = compute_stepwise_metrics(inv_act, inv_pred)

    inference_runtime = benchmark_inference(
        model=model,
        model_name=model_name,
        runtime_loader=runtime_loader,
        cfg=cfg,
        device=device,
        warmup_batches=cfg.runtime_warmup_batches,
        repeat=cfg.runtime_repeats,
    )

    peak_gpu_memory = np.nan
    if torch.cuda.is_available() and device.type == "cuda":
        peak_gpu_memory = torch.cuda.max_memory_allocated(device) / (1024 ** 2)

    runtime_metrics = {
        "TotalParams": count_params(model, trainable_only=False),
        "TrainableParams": count_params(model, trainable_only=True),
        "ActualEpochs": actual_epochs,
        "BestEpoch": best_epoch,
        "TotalFitTimeSec": float(total_fit_time),
        "AvgEpochTimeSec": float(np.mean(history["epoch_time_sec"])),
        "AvgTrainEpochTimeSec": float(np.mean(history["train_epoch_time_sec"])),
        "AvgValEpochTimeSec": float(np.mean(history["val_epoch_time_sec"])),
        "PeakGpuMemoryMB": float(peak_gpu_memory) if np.isfinite(peak_gpu_memory) else np.nan,
    }
    runtime_metrics.update(inference_runtime)

    return overall_metrics, step_metrics, inv_pred, inv_act, history, runtime_metrics


# ============================================================
# 6. Plot functions (modified for multi-horizon)
# ============================================================
def plot_overall_mse_multi_horizon(overall_df, targets, models, pred_lens, save_dir):
    """Plot mean MSE over seeds. Shaded bands indicate ±1 standard deviation."""
    set_journal_style()
    colors, _, markers, linestyles = visual_style()

    fig, axes = plt.subplots(1, len(targets), figsize=(4.5 * len(targets), 4.2),
                             constrained_layout=True)
    if len(targets) == 1:
        axes = [axes]

    summary = (
        overall_df
        .groupby(["Target", "PredLen", "Model"], as_index=False)
        .agg(MSE_mean=("MSE", "mean"), MSE_std=("MSE", "std"))
    )

    for i, target in enumerate(targets):
        ax = axes[i]
        sub = summary[summary["Target"] == target]
        for m in models:
            sm = sub[sub["Model"] == m].set_index("PredLen").reindex(pred_lens)
            x = np.asarray(pred_lens, dtype=float)
            y = sm["MSE_mean"].to_numpy(dtype=float)
            s = sm["MSE_std"].fillna(0.0).to_numpy(dtype=float)
            ax.plot(x, y, label=m, color=colors[m],
                    linestyle=linestyles[m], marker=markers[m],
                    markerfacecolor="white", markeredgewidth=0.8)
            ax.fill_between(x, y - s, y + s, color=colors[m], alpha=0.08, linewidth=0)

        ax.set_title(f"({chr(ord('a')+i)}) {target}", fontweight="bold")
        ax.set_xlabel("Forecast horizon (steps)")
        ax.set_ylabel("Overall MSE")
        ax.grid(axis="y", linestyle="--", linewidth=0.5, alpha=0.35)
        ax.set_xticks(pred_lens)

    handles = [
        mpl.lines.Line2D([0], [0], color=colors[m], linestyle=linestyles[m],
                         marker=markers[m], markerfacecolor="white",
                         markeredgewidth=0.8, label=m)
        for m in models
    ]
    fig.legend(handles=handles, labels=models,
               loc='lower center',
               bbox_to_anchor=(0.5, -0.18),
               ncol=min(6, len(models)),
               frameon=False, columnspacing=1.2, handletextpad=0.5)

    save_paths = []
    for ext in ["png", "pdf", "svg"]:
        p = os.path.join(save_dir, f"overall_mse_multi_horizon_multiseed.{ext}")
        fig.savefig(p)
        save_paths.append(p)
    plt.close(fig)
    return save_paths


def plot_loss_curves_for_pred_len(loss_df, targets, models, pred_len, save_dir):
    """Plot mean training/validation loss over seeds for pred_len."""
    if loss_df is None or loss_df.empty:
        return []

    set_journal_style()
    colors, _, markers, linestyles = visual_style()
    fig, axes = plt.subplots(len(targets), 2, figsize=(8.5, 3.5 * len(targets)),
                             constrained_layout=True)
    if len(targets) == 1:
        axes = np.array([axes])

    panel = 0
    for r, target in enumerate(targets):
        for c, col in enumerate(["TrainLoss", "ValLoss"]):
            ax = axes[r, c]
            sub = loss_df[(loss_df["Target"] == target) & (loss_df["PredLen"] == pred_len)]
            for m in models:
                sm = sub[sub["Model"] == m]
                if sm.empty:
                    continue
                g = sm.groupby("Epoch")[col].agg(["mean", "std"]).reset_index()
                x = g["Epoch"].to_numpy(dtype=float)
                y = g["mean"].to_numpy(dtype=float)
                s = g["std"].fillna(0.0).to_numpy(dtype=float)
                ax.plot(
                    x, y, label=m, color=colors[m], linestyle=linestyles[m],
                    marker=markers[m], markerfacecolor="white", markeredgewidth=0.8,
                    markevery=max(1, len(x) // 8)
                )
                ax.fill_between(x, y - s, y + s, color=colors[m], alpha=0.08, linewidth=0)

            loss_name = "Training loss" if col == "TrainLoss" else "Validation loss"
            ax.set_title(f"({chr(ord('a') + panel)}) {target} (pred={pred_len}) - {loss_name}", fontweight="bold")
            ax.set_xlabel("Epoch")
            ax.set_ylabel("Loss")
            ax.grid(axis="y", linestyle="--", linewidth=0.5, alpha=0.35)
            ax.xaxis.set_major_locator(mpl.ticker.MaxNLocator(integer=True, nbins=6))
            panel += 1

    handles = [
        mpl.lines.Line2D([0], [0], color=colors[m], linestyle=linestyles[m],
                         marker=markers[m], markerfacecolor="white",
                         markeredgewidth=0.8, label=m)
        for m in models
    ]
    fig.legend(handles=handles, labels=models,
               loc='lower center',
               bbox_to_anchor=(0.5, -0.15),
               ncol=min(6, len(models)),
               frameon=False, columnspacing=1.2, handletextpad=0.5)

    save_paths = []
    for ext in ["png", "pdf", "svg"]:
        p = os.path.join(save_dir, f"train_val_loss_pred{pred_len}_multiseed.{ext}")
        fig.savefig(p)
        save_paths.append(p)
    plt.close(fig)
    return save_paths




def plot_runtime_efficiency(runtime_df, targets, models, save_dir):
    set_journal_style()
    colors, hatches, _, _ = visual_style()
    metrics = [
        ("AvgEpochTimeSec", "Avg. epoch time (s)"),
        ("TotalFitTimeSec", "Total fit time (s)"),
        ("InferenceLatencyMsPerWindow", "Inference latency (ms/window)"),
        ("InferenceThroughputWindowsPerSec", "Throughput (windows/s)"),
        ("PeakGpuMemoryMB", "Peak GPU memory (MB)"),
        ("TrainableParams", "Trainable parameters"),
    ]

    fig, axes = plt.subplots(2, 3, figsize=(11, 7), constrained_layout=True)
    axes = axes.reshape(-1)
    x = np.arange(len(models))

    for i, (metric, ylabel) in enumerate(metrics):
        ax = axes[i]
        means = runtime_df.groupby("Model")[metric].mean().reindex(models).values.astype(float)
        stds = runtime_df.groupby("Model")[metric].std().reindex(models).values.astype(float)

        if np.all(~np.isfinite(means)):
            ax.text(0.5, 0.5, "Not available\n(CPU run or no CUDA memory data)",
                    ha="center", va="center", transform=ax.transAxes)
            ax.set_title(f"({chr(ord('a') + i)}) {ylabel}", fontweight="bold")
            ax.set_xticks([])
            ax.set_yticks([])
            continue

        bars = ax.bar(
            x, means, yerr=stds, capsize=2.5, width=0.72,
            color=[colors[m] for m in models],
            edgecolor="black", linewidth=0.8,
            error_kw=dict(elinewidth=0.8, capthick=0.8),
            zorder=3
        )

        for bar, m in zip(bars, models):
            bar.set_hatch(hatches[m])
            if m == "TSF-Resonator":
                bar.set_linewidth(1.2)

        ax.set_title(f"({chr(ord('a') + i)}) {ylabel}", fontweight="bold")
        ax.set_ylabel(ylabel)
        ax.set_xticks(x)
        ax.set_xticklabels(models, rotation=30, ha="right")
        ax.grid(axis="y", linestyle="--", linewidth=0.5, alpha=0.35, zorder=0)

        if metric == "TrainableParams":
            ax.yaxis.set_major_formatter(
                mpl.ticker.FuncFormatter(lambda v, pos: f"{v/1e3:.0f}K" if v < 1e6 else f"{v/1e6:.1f}M")
            )

        ymax = np.nanmax(means + np.nan_to_num(stds, nan=0.0))
        ax.set_ylim(0, ymax * 1.20 if ymax > 0 else 1.0)

    handles = [
        mpl.patches.Patch(facecolor=colors[m], edgecolor="black", linewidth=0.8,
                          hatch=hatches[m], label=m)
        for m in models
    ]
    fig.legend(handles=handles, labels=models,
               loc='lower center',
               bbox_to_anchor=(0.5, -0.12),
               ncol=min(6, len(models)),
               frameon=False, columnspacing=1.2, handletextpad=0.5)

    save_paths = []
    for ext in ["png", "pdf", "svg"]:
        p = os.path.join(save_dir, f"runtime_efficiency_comparison.{ext}")
        fig.savefig(p)
        save_paths.append(p)
    plt.close(fig)
    return save_paths



def plot_latency_by_target(runtime_df, targets, models, save_dir):
    set_journal_style()
    colors, hatches, _, _ = visual_style()
    fig, axes = plt.subplots(1, len(targets), figsize=(10.2, 3.2), constrained_layout=True)
    axes = np.asarray(axes).reshape(-1)

    for i, target in enumerate(targets):
        ax = axes[i]
        sub = runtime_df[runtime_df["Target"] == target].set_index("Model").reindex(models)
        values = sub["InferenceLatencyMsPerWindow"].values.astype(float)
        x = np.arange(len(models))
        bars = ax.bar(x, values, width=0.72, color=[colors[m] for m in models],
                      edgecolor="black", linewidth=0.8, zorder=3)
        for bar, m in zip(bars, models):
            bar.set_hatch(hatches[m])
            if m == "TSF-Resonator":
                bar.set_linewidth(1.2)
        ax.set_title(f"({chr(ord('a') + i)}) {target}", fontweight="bold")
        ax.set_ylabel("Inference latency (ms/window)")
        ax.set_xticks(x)
        ax.set_xticklabels(models, rotation=30, ha="right")
        ax.grid(axis="y", linestyle="--", linewidth=0.5, alpha=0.35, zorder=0)
        ymax = np.nanmax(values)
        ax.set_ylim(0, ymax * 1.18 if ymax > 0 else 1.0)

    save_paths = []
    for ext in ["png", "pdf", "svg"]:
        p = os.path.join(save_dir, f"runtime_latency_by_target.{ext}")
        fig.savefig(p)
        save_paths.append(p)
    plt.close(fig)
    return save_paths



# ============================================================
# 7. Statistical summaries for repeated-seed experiments
# ============================================================
def parse_seed_list(seed_string=None, num_seeds=5, start_seed=2021):
    if seed_string:
        return [int(s.strip()) for s in seed_string.split(",") if s.strip()]
    return [int(start_seed + i) for i in range(num_seeds)]


def t_critical_95(n):
    # Two-sided 95% Student-t critical values for common small sample sizes.
    # Falls back to the normal approximation for large n.
    table = {
        2: 12.706, 3: 4.303, 4: 3.182, 5: 2.776, 6: 2.571,
        7: 2.447, 8: 2.365, 9: 2.306, 10: 2.262, 11: 2.228,
        12: 2.201, 13: 2.179, 14: 2.160, 15: 2.145, 16: 2.131,
        17: 2.120, 18: 2.110, 19: 2.101, 20: 2.093,
    }
    return table.get(int(n), 1.96)


def summarize_repeated_runs(df, group_cols, metric_cols):
    rows = []
    grouped = df.groupby(group_cols, dropna=False)
    for keys, sub in grouped:
        if not isinstance(keys, tuple):
            keys = (keys,)
        row = {c: v for c, v in zip(group_cols, keys)}
        n = int(sub["Seed"].nunique()) if "Seed" in sub.columns else int(len(sub))
        row["NumSeeds"] = n
        for metric in metric_cols:
            values = pd.to_numeric(sub[metric], errors="coerce").dropna().to_numpy(dtype=float)
            n_eff = len(values)
            mean = float(np.mean(values)) if n_eff else np.nan
            std = float(np.std(values, ddof=1)) if n_eff > 1 else 0.0
            sem = float(std / np.sqrt(n_eff)) if n_eff > 0 else np.nan
            ci = float(t_critical_95(n_eff) * sem) if n_eff > 1 else 0.0
            row[f"{metric}_mean"] = mean
            row[f"{metric}_std"] = std
            row[f"{metric}_sem"] = sem
            row[f"{metric}_ci95"] = ci
            row[f"{metric}_ci95_low"] = mean - ci if np.isfinite(mean) else np.nan
            row[f"{metric}_ci95_high"] = mean + ci if np.isfinite(mean) else np.nan
        rows.append(row)
    return pd.DataFrame(rows)


def holm_bonferroni(p_values):
    """Return Holm-Bonferroni adjusted p-values in the original order."""
    p = np.asarray(p_values, dtype=float)
    m = len(p)
    order = np.argsort(p)
    adjusted = np.empty(m, dtype=float)
    running_max = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * p[idx]
        running_max = max(running_max, val)
        adjusted[idx] = min(running_max, 1.0)
    return adjusted


def paired_test(x, y):
    """Wilcoxon signed-rank test if scipy is available; otherwise paired t-test fallback."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    if len(x) < 2:
        return np.nan, "insufficient"

    diff = x - y
    if np.allclose(diff, 0):
        return 1.0, "all_equal"

    try:
        from scipy.stats import wilcoxon
        return float(wilcoxon(x, y, zero_method="wilcox", alternative="two-sided").pvalue), "wilcoxon"
    except Exception:
        n = len(diff)
        sd = np.std(diff, ddof=1)
        if sd == 0:
            return 1.0, "paired_t_fallback"
        t_stat = abs(np.mean(diff) / (sd / np.sqrt(n)))
        p = math.erfc(t_stat / math.sqrt(2.0))
        return float(p), "paired_t_fallback"


def pairwise_tests_vs_reference(overall_df, reference_model="TSF-Resonator",
                                metrics=("MSE", "MAE", "RMSE", "R2")):
    rows = []
    for (target, pred_len), sub in overall_df.groupby(["Target", "PredLen"]):
        models_here = sorted(sub["Model"].unique())
        for metric in metrics:
            p_values = []
            temp_rows = []
            ref = sub[sub["Model"] == reference_model][["Seed", metric]].rename(columns={metric: "ref"})
            if ref.empty:
                continue
            for model in models_here:
                if model == reference_model:
                    continue
                comp = sub[sub["Model"] == model][["Seed", metric]].rename(columns={metric: "comp"})
                merged = ref.merge(comp, on="Seed", how="inner")
                if merged.empty:
                    continue
                p_raw, test_name = paired_test(merged["ref"].values, merged["comp"].values)
                temp_rows.append({
                    "Target": target,
                    "PredLen": pred_len,
                    "Metric": metric,
                    "ReferenceModel": reference_model,
                    "ComparedModel": model,
                    "NumPairs": int(len(merged)),
                    "ReferenceMean": float(np.mean(merged["ref"].values)),
                    "ComparedMean": float(np.mean(merged["comp"].values)),
                    "MeanDifference_ReferenceMinusCompared": float(np.mean(merged["ref"].values - merged["comp"].values)),
                    "PValue": p_raw,
                    "Test": test_name,
                })
                p_values.append(p_raw)
            if temp_rows:
                p_adj = holm_bonferroni(p_values)
                for row, adj in zip(temp_rows, p_adj):
                    row["AdjustedPValue_Holm"] = float(adj)
                    row["Significant_0.05"] = bool(adj < 0.05)
                    rows.append(row)
    return pd.DataFrame(rows)


def make_mean_std_latex_string(mean, std, decimals=4):
    if not np.isfinite(mean):
        return "--"
    if not np.isfinite(std):
        std = 0.0
    return f"{mean:.{decimals}f} $\\pm$ {std:.{decimals}f}"


def export_latex_ready_metric_tables(summary_df, log_dir, metrics=("MSE", "MAE", "RMSE", "R2")):
    """Export compact CSV matrices whose cells are already formatted as mean ± std."""
    for metric in metrics:
        tmp = summary_df.copy()
        tmp[f"{metric}_text"] = tmp.apply(
            lambda r: make_mean_std_latex_string(r[f"{metric}_mean"], r[f"{metric}_std"], 4),
            axis=1
        )
        mat = tmp.pivot_table(index=["Target", "PredLen"], columns="Model",
                              values=f"{metric}_text", aggfunc="first")
        mat.to_csv(os.path.join(log_dir, f"overall_{metric.lower()}_mean_std_latex_matrix.csv"))

# ============================================================
# 8. Main
# ============================================================
def main():
    parser = argparse.ArgumentParser(
        description="Multi-seed main experiments for TSF-Resonator and baseline forecasters."
    )
    parser.add_argument("--num_seeds", type=int, default=5,
                        help="Number of random seeds. Ignored when --seeds is provided.")
    parser.add_argument("--start_seed", type=int, default=2021,
                        help="First seed when --seeds is not provided.")
    parser.add_argument("--seeds", type=str, default=None,
                        help="Comma-separated seed list, e.g., 2021,2022,2023,2024,2025.")
    parser.add_argument("--output_dir", type=str, default=None,
                        help="Output directory. Defaults to GlobalConfig.output_dir.")
    parser.add_argument("--targets", nargs="+", default=["out TP", "out orthophosphate", "out TN"],
                        help="Target columns to evaluate.")
    parser.add_argument("--models", nargs="+",
                        default=["Persistence", "DLinear", "SparseTSF", "MixLinear", "PatchTST", "iTransformer", "TSF-Resonator"],
                        help=("Models to evaluate. Use Persistence for the last-observation baseline; "
                              "the alias/misspelling 'persistance' is also accepted."))
    parser.add_argument("--pred_lens", nargs="+", type=int, default=[12, 24, 48, 96],
                        help="Prediction horizons.")
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--learning_rate", type=float, default=5e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--runtime_repeats", type=int, default=5)
    parser.add_argument("--runtime_batch_size", type=int, default=64)
    parser.add_argument("--deterministic", action="store_true",
                        help="Use deterministic cuDNN settings where possible.")
    args = parser.parse_args()

    seeds = parse_seed_list(args.seeds, args.num_seeds, args.start_seed)

    cfg = GlobalConfig()
    cfg.seq_len = 96
    cfg.batch_size = args.batch_size
    cfg.epochs = args.epochs
    cfg.patience = args.patience
    cfg.learning_rate = args.learning_rate
    cfg.weight_decay = args.weight_decay
    cfg.loss_name = "huber"
    cfg.huber_delta = 1.0
    cfg.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Use all numeric variables as input and forecast only the specified target
    # through target_idx. Set feature_mode="topk" to recover the old behavior.
    cfg.feature_mode = "all"
    cfg.use_time_features = True
    cfg.use_target_history_features = True
    cfg.plot_correlation = True
    cfg.max_corr_plot_features = 60

    cfg.runtime_batch_size = args.runtime_batch_size
    cfg.runtime_warmup_batches = 5
    cfg.runtime_repeats = args.runtime_repeats

    if args.output_dir is not None:
        cfg.output_dir = args.output_dir

    targets = args.targets
    models = deduplicate_preserve_order([canonical_model_name(m) for m in args.models])
    pred_lens = args.pred_lens

    fig_dir = os.path.join(cfg.output_dir, "figures")
    log_dir = os.path.join(cfg.output_dir, "logs")
    pred_dir = os.path.join(cfg.output_dir, "predictions")
    os.makedirs(fig_dir, exist_ok=True)
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(pred_dir, exist_ok=True)

    print("=" * 80)
    print("Multi-seed main experiment")
    print(f"Seeds: {seeds}")
    print(f"Targets: {targets}")
    print(f"Models: {models}")
    print(f"Prediction horizons: {pred_lens}")
    print(f"Device: {cfg.device}")
    print("=" * 80)

    overall_rows = []
    stepwise_rows = []
    loss_rows = []
    runtime_rows = []

    for target in targets:
        print(f"\n{'=' * 70}\nProcessing target: {target}\n{'=' * 70}")
        cfg.target_col = target

        for pred_len in pred_lens:
            cfg.pred_len = pred_len
            print(f"  --- Prediction horizon: {pred_len} ---")

            # Data split is fixed across seeds to avoid temporal leakage and to
            # isolate training stochasticity: initialization, mini-batch order,
            # dropout masks, and GPU-level stochasticity.
            processor = DataProcessor(cfg)
            data_scaled = processor.prepare_data()
            target_idx = processor.target_idx
            num_vars = data_scaled.shape[1]

            print(
                f"  Input feature mode: {getattr(cfg, 'feature_mode', 'all')} | "
                f"num_vars={num_vars} | target_col={cfg.target_col} | target_idx={target_idx}"
            )
            print_model_input_variables(
                processor=processor,
                cfg=cfg,
                target_idx=target_idx,
                num_vars=num_vars,
                data_scaled=data_scaled,
                indent="  ",
            )

            train_len = int(len(data_scaled) * cfg.train_ratio)
            val_len = int(len(data_scaled) * cfg.val_ratio)
            train_data = data_scaled[:train_len]
            val_data = data_scaled[train_len:train_len + val_len]
            test_data = data_scaled[train_len + val_len:]

            train_set = TimeSeriesDataset(train_data, cfg.seq_len, cfg.pred_len)
            val_set = TimeSeriesDataset(val_data, cfg.seq_len, cfg.pred_len)
            test_set = TimeSeriesDataset(test_data, cfg.seq_len, cfg.pred_len)

            for seed in seeds:
                print(f"\n  >>> Seed: {seed}")
                set_seed(seed, deterministic=args.deterministic)

                # The same seed-specific generator is reused for each model so
                # that the shuffled mini-batch order is paired across models.
                for model_name in models:
                    action = "Evaluating and benchmarking baseline" if model_name == "Persistence" else "Training and benchmarking model"
                    print(f"\n  {action}: {model_name} | target={target} | pred={pred_len} | seed={seed}")

                    set_seed(seed, deterministic=args.deterministic)
                    gen = torch.Generator()
                    gen.manual_seed(seed)

                    train_loader = DataLoader(
                        train_set, cfg.batch_size, shuffle=True, drop_last=True,
                        generator=gen
                    )
                    val_loader = DataLoader(val_set, cfg.batch_size, shuffle=False)
                    test_loader = DataLoader(test_set, batch_size=1, shuffle=False)
                    runtime_loader = DataLoader(
                        test_set, batch_size=cfg.runtime_batch_size,
                        shuffle=False, drop_last=False
                    )

                    model = build_model(model_name, cfg, num_vars).to(cfg.device)

                    overall_metrics, step_metrics, inv_pred, inv_act, history, runtime_metrics = train_and_evaluate(
                        model=model,
                        train_loader=train_loader,
                        val_loader=val_loader,
                        test_loader=test_loader,
                        runtime_loader=runtime_loader,
                        cfg=cfg,
                        device=cfg.device,
                        target_idx=target_idx,
                        num_vars=num_vars,
                        scaler=processor.scaler,
                        model_name=model_name,
                        seed=seed,
                    )

                    overall_rows.append({
                        "Seed": seed,
                        "Target": target,
                        "PredLen": pred_len,
                        "Model": model_name,
                        "MSE": overall_metrics["MSE"],
                        "MAE": overall_metrics["MAE"],
                        "RMSE": overall_metrics["RMSE"],
                        "R2": overall_metrics["R2"],
                    })

                    step_metrics = step_metrics.copy()
                    step_metrics.insert(0, "Seed", seed)
                    step_metrics.insert(1, "Target", target)
                    step_metrics.insert(2, "PredLen", pred_len)
                    step_metrics.insert(3, "Model", model_name)
                    stepwise_rows.append(step_metrics)

                    # Store loss history only for pred_len == 96 to keep output compact.
                    if pred_len == 96:
                        for epoch_idx in range(len(history["train_loss"])):
                            loss_rows.append({
                                "Seed": seed,
                                "Target": target,
                                "PredLen": pred_len,
                                "Model": model_name,
                                "Epoch": epoch_idx + 1,
                                "TrainLoss": history["train_loss"][epoch_idx],
                                "ValLoss": history["val_loss"][epoch_idx],
                                "EpochTimeSec": history["epoch_time_sec"][epoch_idx],
                                "TrainEpochTimeSec": history["train_epoch_time_sec"][epoch_idx],
                                "ValEpochTimeSec": history["val_epoch_time_sec"][epoch_idx],
                            })

                    # Runtime is measured only for pred_len=96 as the representative setting.
                    if pred_len == 96:
                        runtime_row = {
                            "Seed": seed,
                            "Target": target,
                            "PredLen": pred_len,
                            "Model": model_name,
                            "Device": str(cfg.device),
                            "SeqLen": cfg.seq_len,
                            "TrainBatchSize": cfg.batch_size,
                            "RuntimeBatchSize": cfg.runtime_batch_size,
                        }
                        runtime_row.update(runtime_metrics)
                        runtime_rows.append(runtime_row)

                    safe_target = target.replace(" ", "_").replace("/", "_")
                    np.savez_compressed(
                        os.path.join(pred_dir, f"predictions_{safe_target}_{model_name}_pred{pred_len}_seed{seed}.npz"),
                        pred=inv_pred,
                        actual=inv_act,
                        target=target,
                        model=model_name,
                        seed=seed,
                        seq_len=cfg.seq_len,
                        pred_len=cfg.pred_len,
                    )

                    print(
                        f"  Overall | seed={seed} | MSE={overall_metrics['MSE']:.6f}, "
                        f"MAE={overall_metrics['MAE']:.6f}, "
                        f"RMSE={overall_metrics['RMSE']:.6f}, "
                        f"R2={overall_metrics['R2']:.6f}"
                    )
                    if pred_len == 96:
                        print(
                            f"  Runtime | AvgEpoch={runtime_metrics['AvgEpochTimeSec']:.3f}s, "
                            f"TotalFit={runtime_metrics['TotalFitTimeSec']:.3f}s, "
                            f"Latency={runtime_metrics['InferenceLatencyMsPerWindow']:.4f} ms/window, "
                            f"Throughput={runtime_metrics['InferenceThroughputWindowsPerSec']:.2f} windows/s"
                        )

    overall_df = pd.DataFrame(overall_rows)
    stepwise_df = pd.concat(stepwise_rows, ignore_index=True) if stepwise_rows else pd.DataFrame()
    loss_df = pd.DataFrame(loss_rows) if loss_rows else pd.DataFrame()
    runtime_df = pd.DataFrame(runtime_rows) if runtime_rows else pd.DataFrame()

    overall_df.to_csv(os.path.join(log_dir, "overall_metrics_by_seed.csv"), index=False, float_format="%.10f")
    if not stepwise_df.empty:
        stepwise_df.to_csv(os.path.join(log_dir, "stepwise_metrics_by_seed.csv"), index=False, float_format="%.10f")
    if not loss_df.empty:
        loss_df.to_csv(os.path.join(log_dir, "loss_history_pred96_by_seed.csv"), index=False, float_format="%.10f")
    if not runtime_df.empty:
        runtime_df.to_csv(os.path.join(log_dir, "runtime_efficiency_metrics_pred96_by_seed.csv"), index=False, float_format="%.10f")

    metric_cols = ["MSE", "MAE", "RMSE", "R2"]
    overall_summary = summarize_repeated_runs(
        overall_df,
        group_cols=["Target", "PredLen", "Model"],
        metric_cols=metric_cols
    )
    overall_summary.to_csv(os.path.join(log_dir, "overall_metrics_summary_mean_std_ci95.csv"),
                           index=False, float_format="%.10f")

    if not stepwise_df.empty:
        stepwise_summary = summarize_repeated_runs(
            stepwise_df,
            group_cols=["Target", "PredLen", "Model", "Step"],
            metric_cols=metric_cols
        )
        stepwise_summary.to_csv(os.path.join(log_dir, "stepwise_metrics_summary_mean_std_ci95.csv"),
                                index=False, float_format="%.10f")

    # Export matrices for paper tables.
    for metric in metric_cols:
        mean_mat = overall_summary.pivot_table(
            index=["Target", "PredLen"], columns="Model", values=f"{metric}_mean", aggfunc="first"
        )
        std_mat = overall_summary.pivot_table(
            index=["Target", "PredLen"], columns="Model", values=f"{metric}_std", aggfunc="first"
        )
        ci_mat = overall_summary.pivot_table(
            index=["Target", "PredLen"], columns="Model", values=f"{metric}_ci95", aggfunc="first"
        )
        mean_mat.to_csv(os.path.join(log_dir, f"overall_{metric.lower()}_mean_matrix.csv"), float_format="%.10f")
        std_mat.to_csv(os.path.join(log_dir, f"overall_{metric.lower()}_std_matrix.csv"), float_format="%.10f")
        ci_mat.to_csv(os.path.join(log_dir, f"overall_{metric.lower()}_ci95_matrix.csv"), float_format="%.10f")

    export_latex_ready_metric_tables(overall_summary, log_dir, metrics=metric_cols)

    pairwise_df = pairwise_tests_vs_reference(
        overall_df,
        reference_model="TSF-Resonator",
        metrics=metric_cols
    )
    if not pairwise_df.empty:
        pairwise_df.to_csv(os.path.join(log_dir, "pairwise_tests_vs_tsf_resonator_holm.csv"),
                           index=False, float_format="%.10f")

    if not runtime_df.empty:
        runtime_numeric = [
            "TotalParams", "TrainableParams", "ActualEpochs", "BestEpoch",
            "TotalFitTimeSec", "AvgEpochTimeSec", "AvgTrainEpochTimeSec", "AvgValEpochTimeSec",
            "InferenceLatencyMsPerWindow", "InferenceLatencyMsPerBatch",
            "InferenceThroughputWindowsPerSec", "PeakGpuMemoryMB",
        ]
        runtime_summary = runtime_df.groupby("Model")[runtime_numeric].agg(["mean", "std"]).reindex(models)
        runtime_summary.to_csv(os.path.join(log_dir, "runtime_efficiency_summary_pred96_mean_std.csv"),
                               float_format="%.10f")

    # Figures.
    plot_overall_mse_multi_horizon(overall_df, targets, models, pred_lens, fig_dir)
    if not loss_df.empty:
        plot_loss_curves_for_pred_len(loss_df, targets, models, 96, fig_dir)
    if not runtime_df.empty:
        plot_runtime_efficiency(runtime_df, targets, models, fig_dir)
        plot_latency_by_target(runtime_df, targets, models, fig_dir)

    print(f"\nAll multi-seed results saved under: {cfg.output_dir}")
    print("Key output files:")
    print(os.path.join(log_dir, "overall_metrics_by_seed.csv"))
    print(os.path.join(log_dir, "overall_metrics_summary_mean_std_ci95.csv"))
    print(os.path.join(log_dir, "pairwise_tests_vs_tsf_resonator_holm.csv"))
    print(os.path.join(log_dir, "overall_mse_mean_std_latex_matrix.csv"))
    print(os.path.join(fig_dir, "overall_mse_multi_horizon_multiseed.[png|pdf|svg]"))
    print(os.path.join(fig_dir, "train_val_loss_pred96_multiseed.[png|pdf|svg]"))


if __name__ == "__main__":
    main()
