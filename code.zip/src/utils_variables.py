import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def evaluate_metrics(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    return mae, rmse, r2


def inverse_transform_target(pred_array, actual_array, scaler, target_idx, num_vars):
    n = len(pred_array)
    dummy_pred = np.zeros((n, num_vars))
    dummy_act = np.zeros((n, num_vars))
    dummy_pred[:, target_idx] = pred_array
    dummy_act[:, target_idx] = actual_array
    inv_pred = scaler.inverse_transform(dummy_pred)[:, target_idx]
    inv_act = scaler.inverse_transform(dummy_act)[:, target_idx]
    return inv_pred, inv_act


def inverse_transform_window(pred_array, actual_array, scaler, target_idx, num_vars):
    """Inverse-transform one target window with shape [N, pred_len]."""
    n, horizon = pred_array.shape
    dummy_pred = np.zeros((n * horizon, num_vars))
    dummy_act = np.zeros((n * horizon, num_vars))
    dummy_pred[:, target_idx] = pred_array.flatten()
    dummy_act[:, target_idx] = actual_array.flatten()
    inv_pred = scaler.inverse_transform(dummy_pred)[:, target_idx].reshape(n, horizon)
    inv_act = scaler.inverse_transform(dummy_act)[:, target_idx].reshape(n, horizon)
    return inv_pred, inv_act


def inverse_transform_all_windows(pred_array, actual_array, scaler):
    """
    Inverse-transform full multivariate forecast windows.

    Args:
        pred_array:   [num_windows, pred_len, num_vars]
        actual_array: [num_windows, pred_len, num_vars]
        scaler: fitted sklearn StandardScaler over all variables

    Returns:
        inv_pred, inv_act with the same shape [num_windows, pred_len, num_vars]
    """
    pred_array = np.asarray(pred_array)
    actual_array = np.asarray(actual_array)

    if pred_array.ndim != 3 or actual_array.ndim != 3:
        raise ValueError(
            f"Expected 3D arrays [num_windows, pred_len, num_vars], "
            f"got pred={pred_array.shape}, actual={actual_array.shape}"
        )
    if pred_array.shape != actual_array.shape:
        raise ValueError(f"Prediction and actual shapes differ: {pred_array.shape} vs {actual_array.shape}")

    n, horizon, num_vars = pred_array.shape
    inv_pred = scaler.inverse_transform(pred_array.reshape(-1, num_vars)).reshape(n, horizon, num_vars)
    inv_act = scaler.inverse_transform(actual_array.reshape(-1, num_vars)).reshape(n, horizon, num_vars)
    return inv_pred, inv_act


def plot_overall_scatter(cfg, y_true, y_pred, seed=None, save_suffix=""):
    mae, rmse, r2 = evaluate_metrics(y_true, y_pred)
    prefix = f'overall{ "_seed"+str(seed) if seed is not None else "" }{save_suffix}'

    plt.figure(figsize=(8, 8))
    plt.scatter(y_true, y_pred, s=2, alpha=0.5, c="navy")
    lims = [min(y_true.min(), y_pred.min()), max(y_true.max(), y_pred.max())]
    plt.plot(lims, lims, "r--", linewidth=1.5)
    plt.xlabel("Actual")
    plt.ylabel("Predicted")
    plt.title(f"Overall Scatter (R2={r2:.4f}, RMSE={rmse:.4f})")
    plt.tight_layout()
    plt.savefig(os.path.join(cfg.output_dir, "figures", f"{prefix}_scatter.png"), dpi=300)
    plt.close()

    residuals = y_true - y_pred
    plt.figure(figsize=(10, 5))
    plt.hist(residuals, bins=80, color="gray", alpha=0.7, density=True)
    plt.xlabel("Residual")
    plt.ylabel("Density")
    plt.title("Residual Distribution")
    plt.grid(True, linestyle=":", alpha=0.6)
    plt.savefig(os.path.join(cfg.output_dir, "figures", f"{prefix}_residuals.png"), dpi=300)
    plt.close()


def save_overall_metrics(cfg, metrics_dict, seed=None):
    path = os.path.join(cfg.output_dir, "logs", f'overall_metrics{"_seed"+str(seed) if seed is not None else ""}.txt')
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"Overall over {metrics_dict['pred_len']} steps\n")
        f.write(f"MAE : {metrics_dict['mae']:.6f}\n")
        f.write(f"RMSE: {metrics_dict['rmse']:.6f}\n")
        f.write(f"R2  : {metrics_dict['r2']:.6f}\n")


import time
import torch
from thop import profile


def compute_model_lite_metrics(model, input_tensor, device, num_warmup=3, num_runs=10):
    model.eval()
    model = model.to(device)
    input_tensor = input_tensor.to(device)

    total_params = sum(p.numel() for p in model.parameters())
    params_M = total_params / 1e6

    try:
        flops, _ = profile(model, inputs=(input_tensor,), verbose=False)
        flops_M = flops / 1e6
        flops_display = f"{flops_M/1000:.2f} G" if flops_M >= 1000 else f"{flops_M:.2f} M"
    except Exception as e:
        print(f"FLOPs computation failed: {e}")
        flops_M = float("nan")
        flops_display = "N/A"

    with torch.no_grad():
        for _ in range(num_warmup):
            _ = model(input_tensor)
        if device.type == "cuda":
            torch.cuda.synchronize()
        start_time = time.time()
        for _ in range(num_runs):
            _ = model(input_tensor)
        if device.type == "cuda":
            torch.cuda.synchronize()
        elapsed_time = time.time() - start_time
        inference_time_ms = (elapsed_time / num_runs) * 1000.0

    return {
        "params_M": params_M,
        "flops_M": flops_M,
        "flops_display": flops_display,
        "inference_time_ms": inference_time_ms,
    }


def save_lite_metrics(cfg, metrics_dict, seed=None):
    import json

    path = os.path.join(cfg.output_dir, "logs", f'lite_metrics{"_seed"+str(seed) if seed is not None else ""}.json')
    serializable = {
        k: float(v) if isinstance(v, (np.floating, float)) else v
        for k, v in metrics_dict.items()
        if k != "flops_display"
    }
    serializable["flops_display"] = metrics_dict["flops_display"]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(serializable, f, indent=2)
    print(f"Lite metrics saved to {path}")
