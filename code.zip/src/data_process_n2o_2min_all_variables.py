import os
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt


DEFAULT_N2O_TARGET = "BIOLOGY.LINE 3 TANK 1.N2O value"

STATE_KEYWORDS = [
    "PROCESSPHASE",
    "PHASECODE",
    "STATE.SWM",
    "INLET TANK",
    "OUTLET TANK",
]

DROP_IF_MISSING_KEYWORDS = [
    "quality",
]


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)


def safe_name(name):
    return str(name).replace("/", "_").replace("\\", "_").replace(" ", "_").replace(":", "_")


def is_state_column(col):
    upper = str(col).upper()
    return any(k in upper for k in STATE_KEYWORDS)


def find_time_column(df):
    preferred = ["_time", "time", "timestamp", "datetime", "date"]
    lower_map = {str(c).lower(): c for c in df.columns}

    for name in preferred:
        if name in lower_map:
            return lower_map[name]

    for col in df.columns[:3]:
        parsed = pd.to_datetime(df[col], errors="coerce", utc=True)
        if parsed.notna().mean() > 0.8:
            return col

    raise ValueError(
        "Cannot identify time column. Use '_time', 'time', 'timestamp', 'datetime', or 'date'."
    )


def parse_time_series(series, timezone="Europe/Copenhagen"):
    text = series.astype(str)
    has_tz = text.str.contains(r"([+-]\d{2}:\d{2}|Z)$", regex=True, na=False).any()

    if has_tz:
        dt = pd.to_datetime(series, errors="coerce", utc=True)
        dt = dt.dt.tz_convert(timezone).dt.tz_localize(None)
        return dt

    return pd.to_datetime(series, errors="coerce")


def read_table_robust(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Data file not found: {path}")

    try:
        df = pd.read_csv(
            path,
            sep=None,
            engine="python",
            na_values=["", " ", "NA", "NaN", "nan", "null", "None"],
        )
    except Exception:
        df = pd.read_csv(
            path,
            sep="\t",
            engine="python",
            na_values=["", " ", "NA", "NaN", "nan", "null", "None"],
        )

    if df.shape[1] <= 1:
        df = pd.read_csv(
            path,
            sep="\t",
            engine="python",
            na_values=["", " ", "NA", "NaN", "nan", "null", "None"],
        )

    df.columns = [" ".join(str(c).replace("\ufeff", "").split()) for c in df.columns]
    return df


class N2O2MinDataProcessor:
    """
    Adapter for the public N2O WWTP data at 2-min frequency.

    This processor does not modify the model architecture. It only prepares
    the public N2O data into the same tensor format used by the original
    experiments:
        x: [seq_len, num_vars]
        y: [pred_len, num_vars]

    Default experimental setting:
        sample interval = 2 min
        seq_len = 96
        pred_len = 12, 24, 48, 96

    Therefore:
        seq_len=96 means 192 minutes of input history.
        pred_len=96 means 192 minutes of forecasting horizon.
    """

    def __init__(self, config):
        self.cfg = config
        self.scaler = StandardScaler()
        self.selected_features = None
        self.target_idx = None
        self.target_high_threshold = None
        self.time_col = None
        self.data_frame_selected = None

    def get_sample_minutes(self):
        return int(getattr(self.cfg, "sample_minutes", 2))

    def hours_to_steps(self, hours):
        sample_minutes = self.get_sample_minutes()
        return max(1, int(round(hours * 60 / sample_minutes)))

    def load_and_clean(self):
        df = read_table_robust(self.cfg.data_path)

        self.time_col = find_time_column(df)
        df[self.time_col] = parse_time_series(
            df[self.time_col],
            timezone=getattr(self.cfg, "timezone", "Europe/Copenhagen"),
        )
        df = df.dropna(subset=[self.time_col])
        df = df.sort_values(self.time_col)
        df = df.drop_duplicates(subset=[self.time_col], keep="last")
        df = df.set_index(self.time_col)
        df.index = pd.DatetimeIndex(df.index)

        # Use all columns that can be represented as numeric variables.
        # Non-numeric columns become NaN after conversion and are removed by
        # the missing-ratio filter below. This avoids correlation Top-K
        # preselection and lets every usable numeric variable enter the model.
        candidate_cols = list(df.columns)

        if self.cfg.target_col not in candidate_cols:
            n2o_candidates = [c for c in candidate_cols if "N2O" in str(c).upper()]
            raise ValueError(
                f"Target column not found: {self.cfg.target_col}\n"
                f"N2O candidate columns: {n2o_candidates[:20]}"
            )

        data = df[candidate_cols].copy()
        for col in data.columns:
            data[col] = pd.to_numeric(data[col], errors="coerce")

        max_missing = float(getattr(self.cfg, "max_feature_missing_ratio", 0.30))
        missing_ratio = data.isna().mean()

        keep_cols = [
            c for c in data.columns
            if c == self.cfg.target_col or missing_ratio[c] <= max_missing
        ]

        data = data[keep_cols]

        # If a column is entirely non-numeric, interpolation cannot recover it.
        # Drop such columns except for the target, which is checked explicitly.
        all_nan_cols = [c for c in data.columns if c != self.cfg.target_col and data[c].isna().all()]
        if all_nan_cols:
            data = data.drop(columns=all_nan_cols)

        if data[self.cfg.target_col].isna().all():
            raise ValueError(
                f"Target column '{self.cfg.target_col}' is not usable as numeric data."
            )

        max_gap = int(getattr(self.cfg, "max_interpolation_steps", self.hours_to_steps(3)))

        continuous_cols = [c for c in data.columns if not is_state_column(c)]
        state_cols = [c for c in data.columns if is_state_column(c)]

        if continuous_cols:
            data[continuous_cols] = data[continuous_cols].interpolate(
                method="time",
                limit=max_gap,
                limit_direction="both",
            )

        if state_cols:
            data[state_cols] = data[state_cols].ffill(limit=max_gap).bfill(limit=max_gap)

        data = data.dropna(subset=[self.cfg.target_col])
        data = data.dropna(axis=0, how="any")

        if len(data) == 0:
            raise ValueError("No usable rows remain after cleaning.")

        data = data.reset_index().rename(columns={self.time_col: "_time"})
        return data


    def feature_engineering(self, df):
        df = df.copy()
        t = pd.to_datetime(df["_time"])

        if bool(getattr(self.cfg, "add_time_features", True)):
            minute_of_day = t.dt.hour * 60 + t.dt.minute
            df["tod_sin"] = np.sin(2 * np.pi * minute_of_day / 1440.0)
            df["tod_cos"] = np.cos(2 * np.pi * minute_of_day / 1440.0)
            df["hour_sin"] = np.sin(2 * np.pi * t.dt.hour / 24.0)
            df["hour_cos"] = np.cos(2 * np.pi * t.dt.hour / 24.0)
            df["weekday_sin"] = np.sin(2 * np.pi * t.dt.weekday / 7.0)
            df["weekday_cos"] = np.cos(2 * np.pi * t.dt.weekday / 7.0)

        target = self.cfg.target_col

        if bool(getattr(self.cfg, "add_target_lag_features", True)):
            win_4h = self.hours_to_steps(4)
            win_12h = self.hours_to_steps(12)

            df[f"{target}_lag1"] = df[target].shift(1)
            df[f"{target}_lag2"] = df[target].shift(2)

            df[f"{target}_lag_30min"] = df[target].shift(self.hours_to_steps(0.5))
            df[f"{target}_lag_1h"] = df[target].shift(self.hours_to_steps(1))

            df[f"{target}_mean_4h"] = (
                df[target]
                .shift(1)
                .rolling(window=win_4h, min_periods=win_4h)
                .mean()
            )
            df[f"{target}_std_4h"] = (
                df[target]
                .shift(1)
                .rolling(window=win_4h, min_periods=win_4h)
                .std()
            )
            df[f"{target}_max_12h"] = (
                df[target]
                .shift(1)
                .rolling(window=win_12h, min_periods=win_12h)
                .max()
            )

        df = df.dropna().reset_index(drop=True)

        if "_time" in df.columns:
            df = df.drop(columns=["_time"])

        return df

    def select_features(self, df):
        """
        Select model input variables.

        Default behavior:
            cfg.feature_mode = "all"

        In this mode, all numeric columns after cleaning and optional feature
        engineering are used as input variables. The model still forecasts only
        cfg.target_col during training/evaluation by using target_idx.

        Optional backward-compatible behavior:
            cfg.feature_mode = "topk"

        This recovers the old correlation Top-K feature selection.
        """
        df = df.copy()
        target = self.cfg.target_col

        if target not in df.columns:
            raise ValueError(f"Target column missing after feature engineering: {target}")

        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        if target not in numeric_cols:
            raise ValueError(
                f"Target column '{target}' is not numeric after feature engineering."
            )

        train_ratio = float(getattr(self.cfg, "train_ratio", 0.70))
        train_len = int(len(df) * train_ratio)
        train_df = df.iloc[:train_len]

        feature_mode = str(getattr(self.cfg, "feature_mode", "all")).lower()

        if feature_mode == "all":
            selected = numeric_cols
        elif feature_mode == "topk":
            feature_selection_k = int(getattr(self.cfg, "feature_selection_k", 15))
            feature_selection_k = max(1, feature_selection_k)

            if feature_selection_k >= len(numeric_cols):
                selected = numeric_cols
            else:
                corr = (
                    train_df[numeric_cols]
                    .corr(numeric_only=True)[target]
                    .abs()
                    .sort_values(ascending=False)
                )
                selected = corr.head(feature_selection_k).index.tolist()
                if target not in selected:
                    selected.append(target)
        else:
            raise ValueError("cfg.feature_mode must be either 'all' or 'topk'.")

        # Keep the target as the last channel for easier checking. This does
        # not change the model logic, because target_idx is computed afterward.
        selected = [c for c in selected if c != target] + [target]

        self.selected_features = selected
        self.target_idx = selected.index(target)
        self.data_frame_selected = df[selected].copy()

        log_dir = os.path.join(self.cfg.output_dir, "logs")
        fig_dir = os.path.join(self.cfg.output_dir, "figures")
        ensure_dir(log_dir)
        ensure_dir(fig_dir)

        with open(
            os.path.join(log_dir, f"selected_features_{safe_name(target)}.txt"),
            "w",
            encoding="utf-8",
        ) as f:
            f.write("\n".join(selected))

        with open(
            os.path.join(log_dir, f"input_feature_info_{safe_name(target)}.txt"),
            "w",
            encoding="utf-8",
        ) as f:
            f.write(f"feature_mode: {feature_mode}\n")
            f.write(f"target_col: {target}\n")
            f.write(f"target_idx: {self.target_idx}\n")
            f.write(f"num_input_features: {len(selected)}\n\n")
            for i, name in enumerate(selected):
                marker = "  <-- target" if i == self.target_idx else ""
                f.write(f"{i}: {name}{marker}\n")

        plot_correlation = bool(getattr(self.cfg, "plot_correlation", True))
        if plot_correlation:
            try:
                max_plot_features = int(getattr(self.cfg, "max_corr_plot_features", 60))
                plot_cols = selected

                # The model still uses all selected variables. This only limits
                # the heatmap to keep the figure readable.
                if len(plot_cols) > max_plot_features:
                    corr_to_target = (
                        train_df[selected]
                        .corr(numeric_only=True)[target]
                        .abs()
                        .sort_values(ascending=False)
                    )
                    plot_cols = corr_to_target.head(max_plot_features).index.tolist()
                    if target not in plot_cols:
                        plot_cols = [target] + plot_cols[:-1]

                corr_mat = train_df[plot_cols].corr(numeric_only=True).values
                fig, ax = plt.subplots(
                    figsize=(max(6, len(plot_cols) * 0.35), max(5, len(plot_cols) * 0.35))
                )
                im = ax.imshow(corr_mat, aspect="auto", vmin=-1, vmax=1)
                ax.set_title("Input Feature Correlation Matrix")
                ax.set_xticks(np.arange(len(plot_cols)))
                ax.set_yticks(np.arange(len(plot_cols)))
                short_names = [
                    str(c)
                    .replace("BIOLOGY.LINE 3 ", "")
                    .replace("BIOLOGY.", "")
                    .replace(" value", "")
                    for c in plot_cols
                ]
                ax.set_xticklabels(short_names, rotation=90, fontsize=6)
                ax.set_yticklabels(short_names, fontsize=6)
                fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
                fig.tight_layout()
                fig.savefig(
                    os.path.join(fig_dir, f"correlation_{safe_name(target)}.png"),
                    dpi=300,
                )
                plt.close(fig)
            except Exception as exc:
                with open(
                    os.path.join(log_dir, "correlation_plot_warning.txt"),
                    "a",
                    encoding="utf-8",
                ) as f:
                    f.write(f"{target}: {exc}\n")

        return df[selected]


    def normalize(self, df):
        train_ratio = float(getattr(self.cfg, "train_ratio", 0.70))
        train_len = int(len(df) * train_ratio)

        train_values = df.iloc[:train_len].values.astype(np.float32)

        q = float(getattr(self.cfg, "high_event_quantile", 0.90))
        self.target_high_threshold = float(
            np.nanquantile(df.iloc[:train_len][self.cfg.target_col].values, q)
        )

        self.scaler.fit(train_values)
        scaled = self.scaler.transform(df.values.astype(np.float32))
        return scaled.astype(np.float32)

    def prepare_data(self):
        log_dir = os.path.join(self.cfg.output_dir, "logs")
        ensure_dir(log_dir)

        df = self.load_and_clean()
        df = self.feature_engineering(df)
        df = self.select_features(df)
        data_scaled = self.normalize(df)

        report = {
            "data_path": str(self.cfg.data_path),
            "target_col": self.cfg.target_col,
            "sample_minutes": self.get_sample_minutes(),
            "seq_len": int(getattr(self.cfg, "seq_len", 96)),
            "num_rows_after_processing": int(data_scaled.shape[0]),
            "feature_mode": str(getattr(self.cfg, "feature_mode", "all")),
            "num_input_features": int(data_scaled.shape[1]),
            "num_selected_features": int(data_scaled.shape[1]),
            "target_idx": int(self.target_idx),
            "target_high_threshold_train_quantile": float(self.target_high_threshold),
            "selected_features": self.selected_features,
            "train_ratio": float(getattr(self.cfg, "train_ratio", 0.70)),
            "val_ratio": float(getattr(self.cfg, "val_ratio", 0.10)),
            "rolling_steps": {
                "4h": self.hours_to_steps(4),
                "12h": self.hours_to_steps(12),
            },
            "note": "2-min data adapter. pred_len values are kept as step counts. feature_mode='all' uses all usable numeric input variables and target_idx selects the target for loss/metrics.",
        }

        with open(
            os.path.join(log_dir, f"data_adapter_2min_report_{safe_name(self.cfg.target_col)}.json"),
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

        return data_scaled


class TimeSeriesDataset(Dataset):
    def __init__(self, data, seq_len, pred_len):
        self.data = np.asarray(data, dtype=np.float32)
        self.seq_len = int(seq_len)
        self.pred_len = int(pred_len)
        self.n = len(self.data) - self.seq_len - self.pred_len + 1

        if self.n <= 0:
            raise ValueError(
                f"Not enough data for seq_len={seq_len}, pred_len={pred_len}. "
                f"Data length={len(self.data)}."
            )

    def __len__(self):
        return self.n

    def __getitem__(self, idx):
        x = self.data[idx: idx + self.seq_len]
        y = self.data[idx + self.seq_len: idx + self.seq_len + self.pred_len]
        return torch.FloatTensor(x), torch.FloatTensor(y)
