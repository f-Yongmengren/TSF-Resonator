import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt


class DataProcessor:
    """
    All-variable forecasting processor.

    This processor is designed for the experiment:
        all original numeric variables -> all original numeric variables

    Main differences from the previous single-target processor:
    1. It does NOT create target-specific lag/rolling figures.
    2. It does NOT perform target-correlation feature selection.
    3. It keeps all original numeric variables in the CSV, excluding the time column.
    4. All data-dependent preprocessing parameters are estimated only from the
       training split to avoid temporal leakage:
          - missing-value fallback statistics
          - winsorization thresholds
          - standardization mean/std

    Notes on leakage-free preprocessing:
    - The chronological split is determined by cfg.train_ratio.
    - Training rows may be internally interpolated because they are used only for
      model fitting.
    - Validation/test rows are never used to estimate preprocessing parameters.
      Missing values after the training period are filled causally using only
      previous available values, then any remaining values are filled with
      training-only fallback statistics.
    """

    def __init__(self, config):
        self.cfg = config
        self.scaler = StandardScaler()
        self.selected_features = None
        self.feature_names = None
        self.target_idx = None  # Kept for backward compatibility; unused in all-variable mode.

        # Stored for reproducibility and downstream inspection.
        self.impute_values = None
        self.winsor_bounds = None

    def _get_train_len(self, n_rows):
        """Return the chronological training length used for all fitted preprocessing."""
        train_ratio = float(getattr(self.cfg, "train_ratio", 0.7))
        if not (0.0 < train_ratio <= 1.0):
            raise ValueError(f"cfg.train_ratio must be in (0, 1], got {train_ratio}")

        train_len = int(n_rows * train_ratio)
        if train_len < 1:
            raise ValueError(
                "Training split is empty. Increase cfg.train_ratio or provide more data."
            )
        return min(train_len, n_rows)

    def _preprocess_without_leakage(self, df):
        """
        Apply missing-value handling and winsorization without using validation/test statistics.

        This method intentionally keeps the public API unchanged. It is called inside
        normalize(), after the original numeric variables have been selected.
        """
        if not isinstance(df, pd.DataFrame):
            df = pd.DataFrame(df)

        processed = df.astype(float).copy()
        train_len = self._get_train_len(len(processed))

        if processed.empty:
            raise ValueError("Input dataframe is empty after numeric-variable selection.")

        # ------------------------------------------------------------------
        # 1) Missing-value handling
        # ------------------------------------------------------------------
        # Training partition:
        #   Interpolate within the training partition only, then use
        #   training-only medians as a fallback. No validation/test rows are
        #   consulted here.
        train_part = processed.iloc[:train_len].copy()
        train_part = train_part.interpolate(method="linear", limit_direction="both")

        train_medians = train_part.median(axis=0, skipna=True)
        train_medians = train_medians.replace([np.inf, -np.inf], np.nan).fillna(0.0)
        train_part = train_part.fillna(train_medians)

        processed.iloc[:train_len] = train_part.values

        # Validation/test partition:
        #   Use only previous available values. This avoids backward-looking
        #   interpolation that could use future validation/test observations.
        processed = processed.ffill()
        processed = processed.fillna(train_medians)

        self.impute_values = train_medians.to_dict()

        # ------------------------------------------------------------------
        # 2) Winsorization
        # ------------------------------------------------------------------
        # Quantile thresholds are estimated only on the already-imputed training
        # partition, then applied unchanged to the full chronological table.
        enable_winsorization = bool(getattr(self.cfg, "enable_winsorization", True))
        if enable_winsorization:
            lower_q = float(getattr(self.cfg, "winsor_lower_quantile", 0.01))
            upper_q = float(getattr(self.cfg, "winsor_upper_quantile", 0.99))

            if not (0.0 <= lower_q <= 1.0 and 0.0 <= upper_q <= 1.0):
                raise ValueError(
                    "winsor_lower_quantile and winsor_upper_quantile must be in [0, 1]."
                )
            if lower_q > upper_q:
                raise ValueError(
                    "winsor_lower_quantile must be <= winsor_upper_quantile."
                )

            train_for_limits = processed.iloc[:train_len]
            lower = train_for_limits.quantile(lower_q)
            upper = train_for_limits.quantile(upper_q)

            lower = lower.replace([np.inf, -np.inf], np.nan)
            upper = upper.replace([np.inf, -np.inf], np.nan)

            self.winsor_bounds = {}
            for col in processed.columns:
                lo = lower[col]
                hi = upper[col]

                # Robust fallback for degenerate columns.
                if pd.isna(lo):
                    lo = train_for_limits[col].min()
                if pd.isna(hi):
                    hi = train_for_limits[col].max()
                if pd.isna(lo):
                    lo = 0.0
                if pd.isna(hi):
                    hi = 0.0
                if lo > hi:
                    lo, hi = hi, lo

                self.winsor_bounds[col] = (float(lo), float(hi))
                processed[col] = processed[col].clip(lower=lo, upper=hi)
        else:
            self.winsor_bounds = None

        return processed

    def load_and_clean(self):
        if not os.path.exists(self.cfg.data_path):
            raise FileNotFoundError(f"Data not found: {self.cfg.data_path}")

        df = pd.read_csv(self.cfg.data_path)

        time_col = getattr(self.cfg, "time_col", "_time")
        if time_col in df.columns:
            df[time_col] = pd.to_datetime(df[time_col])
            df = df.sort_values(time_col).reset_index(drop=True)

        # Important:
        # Do not interpolate, winsorize, normalize, or compute any data-dependent
        # statistic here. Those operations are performed after the chronological
        # training split is known, and all fitted parameters are estimated from
        # the training split only.
        return df

    def select_all_original_numeric_variables(self, df):
        time_col = getattr(self.cfg, "time_col", "_time")
        exclude_cols = set(getattr(self.cfg, "exclude_cols", []))
        exclude_cols.add(time_col)

        numeric_cols = [
            c for c in df.select_dtypes(include=[np.number]).columns.tolist()
            if c not in exclude_cols
        ]

        if len(numeric_cols) == 0:
            raise ValueError(
                "No numeric variables were found for all-variable forecasting. "
                "Check cfg.data_path, cfg.time_col, and cfg.exclude_cols."
            )

        self.selected_features = numeric_cols
        self.feature_names = numeric_cols

        # Save input column names for downstream scripts.
        self.input_cols = numeric_cols
        self.input_columns = numeric_cols
        self.feature_cols = numeric_cols
        self.feature_columns = numeric_cols

        # Locate target column index in the final model input matrix.
        target_col = getattr(self.cfg, "target_col", None)
        if target_col is None:
            raise ValueError("cfg.target_col is not set.")

        if target_col not in numeric_cols:
            raise ValueError(
                f"Target column '{target_col}' is not in numeric model input columns. "
                f"Available numeric columns are: {numeric_cols}"
            )

        self.target_idx = numeric_cols.index(target_col)

        # Write the variable list for reproducibility.
        log_dir = os.path.join(self.cfg.output_dir, "logs")
        fig_dir = os.path.join(self.cfg.output_dir, "figures")
        os.makedirs(log_dir, exist_ok=True)
        os.makedirs(fig_dir, exist_ok=True)

        with open(os.path.join(log_dir, "all_variables.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(numeric_cols))

        # Optional correlation plot. Limit the plot size for very high-dimensional data.
        # This plot is diagnostic only and uses the training partition only.
        max_corr_vars = int(getattr(self.cfg, "max_corr_plot_vars", 40))
        if getattr(self.cfg, "save_correlation_plot", True) and len(numeric_cols) <= max_corr_vars:
            train_len = self._get_train_len(len(df))
            train_df = df.iloc[:train_len][numeric_cols]
            corr = train_df.corr(numeric_only=True)

            plt.figure(figsize=(max(8, 0.35 * len(numeric_cols)), max(6, 0.35 * len(numeric_cols))))
            plt.imshow(corr.values, aspect="auto")
            plt.colorbar(label="Correlation")
            plt.xticks(range(len(numeric_cols)), numeric_cols, rotation=90)
            plt.yticks(range(len(numeric_cols)), numeric_cols)
            plt.title("Correlation Matrix of All Variables")
            plt.tight_layout()
            plt.savefig(os.path.join(fig_dir, "correlation_all_variables.png"), dpi=300)
            plt.close()

        return df[numeric_cols].copy()

    def normalize(self, df):
        # Missing-value imputation and winsorization are fitted using only the
        # training split, then applied to the whole chronological table.
        df_processed = self._preprocess_without_leakage(df)

        train_len = self._get_train_len(len(df_processed))
        self.scaler.fit(df_processed.iloc[:train_len].values)
        return self.scaler.transform(df_processed.values)

    def prepare_data(self):
        df = self.load_and_clean()
        df = self.select_all_original_numeric_variables(df)
        data_scaled = self.normalize(df)
        return data_scaled


class TimeSeriesDataset(Dataset):
    def __init__(self, data, seq_len, pred_len):
        self.data = data
        self.seq_len = seq_len
        self.pred_len = pred_len

    def __len__(self):
        return len(self.data) - self.seq_len - self.pred_len + 1

    def __getitem__(self, idx):
        x = self.data[idx: idx + self.seq_len]
        y = self.data[idx + self.seq_len: idx + self.seq_len + self.pred_len]
        return torch.FloatTensor(x), torch.FloatTensor(y)
