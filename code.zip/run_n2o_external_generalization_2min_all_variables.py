import os
import sys
import time
import math
import random
import argparse

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

from config.global_config import GlobalConfig
from src.data_process_n2o_2min import (
    N2O2MinDataProcessor,
    TimeSeriesDataset,
    DEFAULT_N2O_TARGET,
)

from models.dlinear import Model as DLinearModel
from models.mixlinear import Model as MixLinearModel
from models.sparsetsf import SparseTSF
from models.patchtst import Model as PatchTST
from models.itransformer import Model as ITransformer
from models.tsf_resonator import TSFResonator


TRAINABLE_MODELS = [
    "DLinear",
    "SparseTSF",
    "MixLinear",
    "PatchTST",
    "iTransformer",
    "TSF-Resonator",
]

NAIVE_MODELS = [
    "Persistence",
    "SeasonalNaive",
]


def set_seed(seed=2025, deterministic=True):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        try:
            torch.use_deterministic_algorithms(True, warn_only=True)
        except TypeError:
            try:
                torch.use_deterministic_algorithms(True)
            except Exception:
                pass
        except Exception:
            pass


def sync_device(device):
    if torch.cuda.is_available() and device.type == "cuda":
        torch.cuda.synchronize(device)


def count_params(model, trainable_only=False):
    if trainable_only:
        return int(sum(p.numel() for p in model.parameters() if p.requires_grad))
    return int(sum(p.numel() for p in model.parameters()))


def safe_name(name):
    return str(name).replace("/", "_").replace("\\", "_").replace(" ", "_").replace(":", "_")


def short_target_name(name):
    if "N2O" in str(name).upper():
        return "N2O"
    return str(name).replace("BIOLOGY.LINE 3 ", "").replace(" value", "")


def inverse_transform_window(pred_array, actual_array, scaler, target_idx, num_vars):
    pred_array = np.asarray(pred_array)
    actual_array = np.asarray(actual_array)
    n, horizon = pred_array.shape

    dummy_pred = np.zeros((n * horizon, num_vars), dtype=np.float32)
    dummy_act = np.zeros((n * horizon, num_vars), dtype=np.float32)

    dummy_pred[:, target_idx] = pred_array.reshape(-1)
    dummy_act[:, target_idx] = actual_array.reshape(-1)

    inv_pred = scaler.inverse_transform(dummy_pred)[:, target_idx].reshape(n, horizon)
    inv_act = scaler.inverse_transform(dummy_act)[:, target_idx].reshape(n, horizon)

    return inv_pred, inv_act


def set_journal_style():
    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 9,
        "axes.labelsize": 10,
        "axes.titlesize": 10,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
        "xtick.major.size": 3,
        "ytick.major.size": 3,
        "lines.linewidth": 1.6,
        "lines.markersize": 4.0,
        "figure.dpi": 300,
        "savefig.dpi": 600,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.03,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })


def visual_style():
    colors = {
        "Persistence": "#999999",
        "SeasonalNaive": "#666666",
        "DLinear": "#4C72B0",
        "SparseTSF": "#55A868",
        "MixLinear": "#DD8452",
        "PatchTST": "#8172B3",
        "iTransformer": "#64B5CD",
        "TSF-Resonator": "#C44E52",
    }
    markers = {
        "Persistence": "x",
        "SeasonalNaive": "*",
        "DLinear": "o",
        "SparseTSF": "^",
        "MixLinear": "s",
        "PatchTST": "P",
        "iTransformer": "v",
        "TSF-Resonator": "D",
    }
    linestyles = {
        "Persistence": "--",
        "SeasonalNaive": ":",
        "DLinear": "-",
        "SparseTSF": "--",
        "MixLinear": "-.",
        "PatchTST": ":",
        "iTransformer": (0, (3, 1, 1, 1)),
        "TSF-Resonator": "-",
    }
    return colors, markers, linestyles


def build_model(model_name, cfg, num_vars):
    if model_name == "DLinear":
        class DLinearConfig:
            def __init__(self, seq_len, pred_len, enc_in):
                self.seq_len = seq_len
                self.pred_len = pred_len
                self.enc_in = enc_in
                self.individual = False
                self.decomp_kernel = 25
        return DLinearModel(DLinearConfig(cfg.seq_len, cfg.pred_len, num_vars))

    if model_name == "MixLinear":
        class MixConfig:
            def __init__(self, seq_len, pred_len, enc_in):
                self.seq_len = seq_len
                self.pred_len = pred_len
                self.enc_in = enc_in
                self.period_len = 12
                self.lpf = 6
                self.alpha = 0.5
        return MixLinearModel(MixConfig(cfg.seq_len, cfg.pred_len, num_vars))

    if model_name == "SparseTSF":
        return SparseTSF(
            num_vars=num_vars,
            seq_len=cfg.seq_len,
            pred_len=cfg.pred_len,
            w=12,
        )

    if model_name == "PatchTST":
        class PatchConfig:
            def __init__(self, seq_len, pred_len, enc_in):
                self.enc_in = enc_in
                self.seq_len = seq_len
                self.pred_len = pred_len
                self.e_layers = 3
                self.n_heads = 4
                self.d_model = 64
                self.d_ff = 128
                self.dropout = 0.3
                self.fc_dropout = 0.1
                self.head_dropout = 0.0
                self.individual = False
                self.patch_len = 16
                self.stride = 8
                self.padding_patch = "end"
                self.revin = True
                self.affine = True
                self.subtract_last = False
                self.decomposition = False
                self.kernel_size = 25
        return PatchTST(PatchConfig(cfg.seq_len, cfg.pred_len, num_vars))

    if model_name == "iTransformer":
        class ITConfig:
            def __init__(self, seq_len, pred_len, enc_in):
                self.seq_len = seq_len
                self.pred_len = pred_len
                self.enc_in = enc_in
                self.d_model = 64
                self.n_heads = 4
                self.e_layers = 2
                self.d_ff = 128
                self.dropout = 0.3
                self.activation = "gelu"
                self.output_attention = False
                self.use_norm = True
                self.embed = "fixed"
                self.freq = "h"
                self.factor = 1
                self.padding = 0
                self.features = "M"
                self.label_len = pred_len // 2
        return ITransformer(ITConfig(cfg.seq_len, cfg.pred_len, num_vars))

    if model_name == "TSF-Resonator":
        model = TSFResonator(
            num_vars=num_vars,
            seq_len=cfg.seq_len,
            pred_len=cfg.pred_len,
            trend_scales=[3, 7, 15],
            d_res=16,
            dropout=0.1,
        )
        model.target_idx = -1
        return model

    raise ValueError(f"Unknown model: {model_name}")


def forward_model(model, model_name, x, cfg, device):
    if model_name == "iTransformer":
        bsz, seq_len, _ = x.shape
        x_mark = torch.zeros(bsz, seq_len, 4, device=device)
        y_mark = torch.zeros(bsz, cfg.pred_len, 4, device=device)
        return model(x, x_mark, None, y_mark)

    return model(x)


def extract_target_prediction(pred, model_name, target_idx):
    if model_name == "TSF-Resonator":
        if pred.ndim == 2:
            return pred
        if pred.ndim == 3:
            return pred[:, :, target_idx]
        raise ValueError(f"Unexpected TSF-Resonator output shape: {pred.shape}")

    if pred.ndim == 3:
        return pred[:, :, target_idx]

    if pred.ndim == 2:
        return pred

    raise ValueError(f"Unexpected output shape: {pred.shape}")


def preflight_model_forward_check(models, cfg, num_vars, target_idx, device):
    dummy_x = torch.zeros(2, cfg.seq_len, num_vars, device=device)

    for model_name in models:
        if model_name in NAIVE_MODELS:
            continue

        model = build_model(model_name, cfg, num_vars).to(device)
        if hasattr(model, "target_idx"):
            model.target_idx = target_idx

        model.eval()
        with torch.no_grad():
            pred = forward_model(model, model_name, dummy_x, cfg, device)
            pred_target = extract_target_prediction(pred, model_name, target_idx)

        expected = (2, cfg.pred_len)
        if tuple(pred_target.shape) != expected:
            raise RuntimeError(
                f"Preflight failed for {model_name}: "
                f"target output shape {tuple(pred_target.shape)} != {expected}"
            )

        del model

    if torch.cuda.is_available() and device.type == "cuda":
        torch.cuda.empty_cache()


def compute_metrics(y_true, y_pred):
    y_true = np.asarray(y_true).reshape(-1)
    y_pred = np.asarray(y_pred).reshape(-1)

    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    y_true = y_true[mask]
    y_pred = y_pred[mask]

    if y_true.size == 0:
        return {"MSE": np.nan, "MAE": np.nan, "RMSE": np.nan, "R2": np.nan}

    err = y_true - y_pred
    mse = np.mean(err ** 2)
    mae = np.mean(np.abs(err))
    rmse = np.sqrt(mse)

    ss_res = np.sum(err ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    r2 = np.nan if ss_tot == 0 else 1.0 - ss_res / ss_tot

    return {
        "MSE": float(mse),
        "MAE": float(mae),
        "RMSE": float(rmse),
        "R2": float(r2),
    }


def compute_stepwise_metrics(y_true, y_pred):
    rows = []
    for step in range(y_true.shape[1]):
        m = compute_metrics(y_true[:, step], y_pred[:, step])
        m["Step"] = step + 1
        rows.append(m)

    return pd.DataFrame(rows, columns=["Step", "MSE", "MAE", "RMSE", "R2"])


def compute_high_event_metrics(y_true, y_pred, threshold):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    flat_true = y_true.reshape(-1)
    flat_pred = y_pred.reshape(-1)

    high_mask = flat_true > threshold
    if np.any(high_mask):
        high = compute_metrics(flat_true[high_mask], flat_pred[high_mask])
    else:
        high = {"MSE": np.nan, "MAE": np.nan, "RMSE": np.nan, "R2": np.nan}

    actual_event = (y_true > threshold).any(axis=1)
    pred_event = (y_pred > threshold).any(axis=1)

    tp = int(np.sum(actual_event & pred_event))
    fp = int(np.sum(~actual_event & pred_event))
    fn = int(np.sum(actual_event & ~pred_event))
    tn = int(np.sum(~actual_event & ~pred_event))

    precision = tp / (tp + fp) if (tp + fp) > 0 else np.nan
    recall = tp / (tp + fn) if (tp + fn) > 0 else np.nan

    if np.isfinite(precision) and np.isfinite(recall) and precision + recall > 0:
        f1 = 2 * precision * recall / (precision + recall)
    else:
        f1 = np.nan

    return {
        "HighThreshold": float(threshold),
        "High_MSE": high["MSE"],
        "High_MAE": high["MAE"],
        "High_RMSE": high["RMSE"],
        "High_R2": high["R2"],
        "EventPrecision": float(precision) if np.isfinite(precision) else np.nan,
        "EventRecall": float(recall) if np.isfinite(recall) else np.nan,
        "EventF1": float(f1) if np.isfinite(f1) else np.nan,
        "EventTP": tp,
        "EventFP": fp,
        "EventFN": fn,
        "EventTN": tn,
    }


def benchmark_inference(model, model_name, runtime_loader, cfg, device, warmup_batches=5, repeat=5):
    model.eval()

    with torch.no_grad():
        for i, (x, _) in enumerate(runtime_loader):
            if i >= warmup_batches:
                break
            x = x.to(device)
            _ = forward_model(model, model_name, x, cfg, device)

    sync_device(device)

    total_time = 0.0
    total_batches = 0
    total_windows = 0

    with torch.no_grad():
        for _ in range(repeat):
            sync_device(device)
            start = time.perf_counter()
            nb = 0
            nw = 0

            for x, _ in runtime_loader:
                x = x.to(device)
                _ = forward_model(model, model_name, x, cfg, device)
                nb += 1
                nw += int(x.shape[0])

            sync_device(device)
            end = time.perf_counter()

            total_time += end - start
            total_batches += nb
            total_windows += nw

    return {
        "InferenceLatencyMsPerWindow": float(1000.0 * total_time / max(total_windows, 1)),
        "InferenceLatencyMsPerBatch": float(1000.0 * total_time / max(total_batches, 1)),
        "InferenceThroughputWindowsPerSec": float(total_windows / max(total_time, 1e-12)),
        "RuntimeBenchmarkBatches": int(total_batches),
        "RuntimeBenchmarkWindows": int(total_windows),
    }


def make_naive_prediction_scaled(x, target_idx, pred_len, baseline_name, seasonal_lag):
    if baseline_name == "Persistence":
        base = x[:, -1, target_idx]
    elif baseline_name == "SeasonalNaive":
        if x.shape[1] >= seasonal_lag:
            base = x[:, -seasonal_lag, target_idx]
        else:
            base = x[:, -1, target_idx]
    else:
        raise ValueError(f"Unknown naive baseline: {baseline_name}")

    return base.unsqueeze(1).repeat(1, pred_len)


def benchmark_naive_runtime(test_loader, target_idx, cfg, seasonal_lag):
    start = time.perf_counter()
    total_windows = 0
    total_batches = 0

    for x, _ in test_loader:
        _ = make_naive_prediction_scaled(
            x,
            target_idx,
            cfg.pred_len,
            "Persistence",
            seasonal_lag,
        )
        total_windows += int(x.shape[0])
        total_batches += 1

    elapsed = max(time.perf_counter() - start, 1e-12)

    return {
        "InferenceLatencyMsPerWindow": float(1000.0 * elapsed / max(total_windows, 1)),
        "InferenceLatencyMsPerBatch": float(1000.0 * elapsed / max(total_batches, 1)),
        "InferenceThroughputWindowsPerSec": float(total_windows / elapsed),
        "RuntimeBenchmarkBatches": int(total_batches),
        "RuntimeBenchmarkWindows": int(total_windows),
    }


def evaluate_naive_baseline(test_loader, runtime_loader, cfg, target_idx, num_vars, scaler,
                            baseline_name, high_threshold, seasonal_lag):
    preds = []
    actuals = []

    for x, y in test_loader:
        pred = make_naive_prediction_scaled(
            x,
            target_idx,
            cfg.pred_len,
            baseline_name,
            seasonal_lag,
        )
        preds.append(pred.numpy())
        actuals.append(y[:, :, target_idx].numpy())

    preds = np.concatenate(preds, axis=0)
    actuals = np.concatenate(actuals, axis=0)

    inv_pred, inv_act = inverse_transform_window(
        preds,
        actuals,
        scaler,
        target_idx,
        num_vars,
    )

    overall = compute_metrics(inv_act, inv_pred)
    stepwise = compute_stepwise_metrics(inv_act, inv_pred)
    high = compute_high_event_metrics(inv_act, inv_pred, high_threshold)

    runtime = benchmark_naive_runtime(runtime_loader, target_idx, cfg, seasonal_lag)
    runtime.update({
        "TotalParams": 0,
        "TrainableParams": 0,
        "ActualEpochs": 0,
        "BestEpoch": 0,
        "TotalFitTimeSec": 0.0,
        "AvgEpochTimeSec": 0.0,
        "AvgTrainEpochTimeSec": 0.0,
        "AvgValEpochTimeSec": 0.0,
        "PeakGpuMemoryMB": np.nan,
    })

    return overall, stepwise, high, inv_pred, inv_act, runtime


def load_state_dict_safely(model, ckpt_path, device):
    try:
        state = torch.load(ckpt_path, map_location=device, weights_only=True)
    except TypeError:
        state = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(state)


def train_and_evaluate(model, train_loader, val_loader, test_loader, runtime_loader,
                       cfg, device, target_idx, num_vars, scaler, model_name,
                       high_threshold, seed=None):
    if hasattr(model, "target_idx"):
        model.target_idx = target_idx

    criterion = nn.HuberLoss(delta=cfg.huber_delta) if cfg.loss_name == "huber" else nn.MSELoss()
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=cfg.learning_rate,
        weight_decay=cfg.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="min",
        factor=0.5,
        patience=3,
    )

    ckpt_dir = os.path.join(cfg.output_dir, "checkpoints")
    os.makedirs(ckpt_dir, exist_ok=True)

    seed_tag = f"_seed{seed}" if seed is not None else ""
    ckpt_path = os.path.join(
        ckpt_dir,
        f"best_{model_name}_{safe_name(cfg.target_col)}_pred{cfg.pred_len}{seed_tag}.pth",
    )

    if torch.cuda.is_available() and device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)

    history = {
        "train_loss": [],
        "val_loss": [],
        "train_epoch_time_sec": [],
        "val_epoch_time_sec": [],
        "epoch_time_sec": [],
    }

    best_val = float("inf")
    best_epoch = -1
    early_stop = 0

    sync_device(device)
    total_start = time.perf_counter()

    for epoch in range(cfg.epochs):
        epoch_start = time.perf_counter()

        model.train()
        train_losses = []
        sync_device(device)
        train_start = time.perf_counter()

        for batch_idx, (x, y) in enumerate(train_loader):
            x = x.to(device)
            y = y.to(device)

            pred = forward_model(model, model_name, x, cfg, device)
            pred_target = extract_target_prediction(pred, model_name, target_idx)

            loss = criterion(pred_target, y[:, :, target_idx])

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            train_losses.append(loss.item())

            if cfg.max_train_batches is not None and batch_idx + 1 >= cfg.max_train_batches:
                break

        sync_device(device)
        train_end = time.perf_counter()

        model.eval()
        val_losses = []
        sync_device(device)
        val_start = time.perf_counter()

        with torch.no_grad():
            for batch_idx, (x, y) in enumerate(val_loader):
                x = x.to(device)
                y = y.to(device)

                pred = forward_model(model, model_name, x, cfg, device)
                pred_target = extract_target_prediction(pred, model_name, target_idx)
                loss = criterion(pred_target, y[:, :, target_idx])
                val_losses.append(loss.item())

                if cfg.max_val_batches is not None and batch_idx + 1 >= cfg.max_val_batches:
                    break

        sync_device(device)
        val_end = time.perf_counter()

        train_loss = float(np.mean(train_losses)) if train_losses else np.nan
        val_loss = float(np.mean(val_losses)) if val_losses else np.nan

        scheduler.step(val_loss)

        epoch_end = time.perf_counter()

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["train_epoch_time_sec"].append(float(train_end - train_start))
        history["val_epoch_time_sec"].append(float(val_end - val_start))
        history["epoch_time_sec"].append(float(epoch_end - epoch_start))

        print(
            f"    Epoch {epoch + 1:03d}/{cfg.epochs} | "
            f"train={train_loss:.6f} | val={val_loss:.6f} | "
            f"time={epoch_end - epoch_start:.2f}s"
        )

        if np.isfinite(val_loss) and val_loss < best_val:
            best_val = val_loss
            best_epoch = epoch + 1
            early_stop = 0
            torch.save(model.state_dict(), ckpt_path)
        else:
            early_stop += 1
            if early_stop >= cfg.patience:
                print(f"    Early stopping at epoch {epoch + 1}. Best val={best_val:.6f}")
                break

    sync_device(device)
    total_end = time.perf_counter()

    total_fit_time = total_end - total_start
    actual_epochs = len(history["train_loss"])

    if not os.path.exists(ckpt_path):
        torch.save(model.state_dict(), ckpt_path)
        best_epoch = actual_epochs

    load_state_dict_safely(model, ckpt_path, device)
    model.eval()

    preds = []
    actuals = []

    with torch.no_grad():
        for x, y in test_loader:
            x = x.to(device)

            pred = forward_model(model, model_name, x, cfg, device)
            pred_target = extract_target_prediction(pred, model_name, target_idx)

            preds.append(pred_target.cpu().numpy())
            actuals.append(y[:, :, target_idx].cpu().numpy())

    preds = np.concatenate(preds, axis=0)
    actuals = np.concatenate(actuals, axis=0)

    inv_pred, inv_act = inverse_transform_window(
        preds,
        actuals,
        scaler,
        target_idx,
        num_vars,
    )

    overall = compute_metrics(inv_act, inv_pred)
    stepwise = compute_stepwise_metrics(inv_act, inv_pred)
    high = compute_high_event_metrics(inv_act, inv_pred, high_threshold)

    runtime = benchmark_inference(
        model=model,
        model_name=model_name,
        runtime_loader=runtime_loader,
        cfg=cfg,
        device=device,
        warmup_batches=cfg.runtime_warmup_batches,
        repeat=cfg.runtime_repeats,
    )

    peak_gpu_memory = np.nan
    if torch.cuda.is_available() and device.type == "cuda":
        peak_gpu_memory = torch.cuda.max_memory_allocated(device) / (1024 ** 2)

    runtime.update({
        "TotalParams": count_params(model, trainable_only=False),
        "TrainableParams": count_params(model, trainable_only=True),
        "ActualEpochs": actual_epochs,
        "BestEpoch": best_epoch,
        "TotalFitTimeSec": float(total_fit_time),
        "AvgEpochTimeSec": float(np.mean(history["epoch_time_sec"])),
        "AvgTrainEpochTimeSec": float(np.mean(history["train_epoch_time_sec"])),
        "AvgValEpochTimeSec": float(np.mean(history["val_epoch_time_sec"])),
        "PeakGpuMemoryMB": float(peak_gpu_memory) if np.isfinite(peak_gpu_memory) else np.nan,
    })

    return overall, stepwise, high, inv_pred, inv_act, history, runtime


def parse_seed_list(seed_string=None, num_seeds=5, start_seed=2021):
    if seed_string:
        return [int(s.strip()) for s in seed_string.split(",") if s.strip()]
    return [int(start_seed + i) for i in range(num_seeds)]


def summarize_repeated_runs(df, group_cols, metric_cols):
    rows = []

    for keys, sub in df.groupby(group_cols, dropna=False):
        if not isinstance(keys, tuple):
            keys = (keys,)

        row = {c: v for c, v in zip(group_cols, keys)}
        row["NumSeeds"] = int(sub["Seed"].nunique()) if "Seed" in sub.columns else int(len(sub))

        for metric in metric_cols:
            values = pd.to_numeric(sub[metric], errors="coerce").dropna().to_numpy(dtype=float)

            if len(values) == 0:
                mean = std = sem = ci = np.nan
            else:
                mean = float(np.mean(values))
                std = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
                sem = float(std / np.sqrt(len(values))) if len(values) > 0 else np.nan
                tcrit = 2.776 if len(values) == 5 else 1.96
                ci = float(tcrit * sem) if len(values) > 1 else 0.0

            row[f"{metric}_mean"] = mean
            row[f"{metric}_std"] = std
            row[f"{metric}_sem"] = sem
            row[f"{metric}_ci95"] = ci
            row[f"{metric}_ci95_low"] = mean - ci if np.isfinite(mean) else np.nan
            row[f"{metric}_ci95_high"] = mean + ci if np.isfinite(mean) else np.nan

        rows.append(row)

    return pd.DataFrame(rows)


def paired_test(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]

    if len(x) < 2:
        return np.nan, "insufficient"

    diff = x - y
    if np.allclose(diff, 0):
        return 1.0, "all_equal"

    try:
        from scipy.stats import wilcoxon
        p = wilcoxon(x, y, zero_method="wilcox", alternative="two-sided").pvalue
        return float(p), "wilcoxon"
    except Exception:
        n = len(diff)
        sd = np.std(diff, ddof=1)

        if sd == 0:
            return 1.0, "paired_t_fallback"

        t_stat = abs(np.mean(diff) / (sd / np.sqrt(n)))
        p = math.erfc(t_stat / math.sqrt(2.0))
        return float(p), "paired_t_fallback"


def holm_bonferroni(p_values):
    p = np.asarray(p_values, dtype=float)
    m = len(p)
    order = np.argsort(p)

    adjusted = np.empty(m, dtype=float)
    running_max = 0.0

    for rank, idx in enumerate(order):
        val = (m - rank) * p[idx]
        running_max = max(running_max, val)
        adjusted[idx] = min(running_max, 1.0)

    return adjusted


def pairwise_tests_vs_reference(overall_df, reference_model="TSF-Resonator",
                                metrics=("MSE", "MAE", "RMSE", "R2")):
    rows = []

    for (target, pred_len), sub in overall_df.groupby(["Target", "PredLen"]):
        models_here = sorted(sub["Model"].unique())

        for metric in metrics:
            p_values = []
            temp_rows = []

            ref = sub[sub["Model"] == reference_model][["Seed", metric]].rename(
                columns={metric: "ref"}
            )

            if ref.empty:
                continue

            for model in models_here:
                if model == reference_model:
                    continue

                comp = sub[sub["Model"] == model][["Seed", metric]].rename(
                    columns={metric: "comp"}
                )
                merged = ref.merge(comp, on="Seed", how="inner")

                if merged.empty:
                    continue

                p_raw, test_name = paired_test(merged["ref"].values, merged["comp"].values)

                temp_rows.append({
                    "Target": target,
                    "PredLen": pred_len,
                    "Metric": metric,
                    "ReferenceModel": reference_model,
                    "ComparedModel": model,
                    "NumPairs": int(len(merged)),
                    "ReferenceMean": float(np.mean(merged["ref"].values)),
                    "ComparedMean": float(np.mean(merged["comp"].values)),
                    "MeanDifference_ReferenceMinusCompared": float(
                        np.mean(merged["ref"].values - merged["comp"].values)
                    ),
                    "PValue": p_raw,
                    "Test": test_name,
                })
                p_values.append(p_raw)

            if temp_rows:
                adjusted = holm_bonferroni(p_values)
                for row, adj in zip(temp_rows, adjusted):
                    row["AdjustedPValue_Holm"] = float(adj)
                    row["Significant_0.05"] = bool(adj < 0.05)
                    rows.append(row)

    return pd.DataFrame(rows)


def make_mean_std_latex_string(mean, std, decimals=4):
    if not np.isfinite(mean):
        return "--"
    if not np.isfinite(std):
        std = 0.0
    return f"{mean:.{decimals}f} $\\pm$ {std:.{decimals}f}"


def export_latex_ready_metric_tables(summary_df, log_dir, metrics=("MSE", "MAE", "RMSE", "R2")):
    for metric in metrics:
        tmp = summary_df.copy()
        tmp[f"{metric}_text"] = tmp.apply(
            lambda r: make_mean_std_latex_string(
                r[f"{metric}_mean"],
                r[f"{metric}_std"],
                4,
            ),
            axis=1,
        )
        mat = tmp.pivot_table(
            index=["Target", "PredLen"],
            columns="Model",
            values=f"{metric}_text",
            aggfunc="first",
        )
        mat.to_csv(os.path.join(log_dir, f"n2o_2min_{metric.lower()}_mean_std_latex_matrix.csv"))


def plot_overall_mse(overall_df, targets, models, pred_lens, save_dir):
    set_journal_style()
    colors, markers, linestyles = visual_style()

    fig, axes = plt.subplots(
        1,
        len(targets),
        figsize=(4.5 * len(targets), 4.2),
        constrained_layout=True,
    )

    if len(targets) == 1:
        axes = [axes]

    summary = (
        overall_df
        .groupby(["Target", "PredLen", "Model"], as_index=False)
        .agg(MSE_mean=("MSE", "mean"), MSE_std=("MSE", "std"))
    )

    for i, target in enumerate(targets):
        ax = axes[i]
        sub = summary[summary["Target"] == target]

        for model in models:
            sm = sub[sub["Model"] == model].set_index("PredLen").reindex(pred_lens)
            x = np.asarray(pred_lens, dtype=float)
            y = sm["MSE_mean"].to_numpy(dtype=float)
            s = sm["MSE_std"].fillna(0.0).to_numpy(dtype=float)

            ax.plot(
                x,
                y,
                label=model,
                color=colors[model],
                linestyle=linestyles[model],
                marker=markers[model],
                markerfacecolor="white",
                markeredgewidth=0.8,
            )
            ax.fill_between(x, y - s, y + s, color=colors[model], alpha=0.08, linewidth=0)

        ax.set_title(f"({chr(ord('a') + i)}) {short_target_name(target)}", fontweight="bold")
        ax.set_xlabel("Forecast horizon (steps)")
        ax.set_ylabel("Overall MSE")
        ax.set_xticks(pred_lens)
        ax.grid(axis="y", linestyle="--", linewidth=0.5, alpha=0.35)

    handles = [
        mpl.lines.Line2D(
            [0],
            [0],
            color=colors[m],
            linestyle=linestyles[m],
            marker=markers[m],
            markerfacecolor="white",
            markeredgewidth=0.8,
            label=m,
        )
        for m in models
    ]

    fig.legend(
        handles=handles,
        labels=models,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.18),
        ncol=min(4, len(models)),
        frameon=False,
    )

    for ext in ["png", "pdf", "svg"]:
        fig.savefig(os.path.join(save_dir, f"n2o_2min_overall_mse_multi_horizon.{ext}"))

    plt.close(fig)


def plot_high_event_f1(high_df, targets, models, pred_lens, save_dir):
    set_journal_style()
    colors, markers, linestyles = visual_style()

    summary = (
        high_df
        .groupby(["Target", "PredLen", "Model"], as_index=False)
        .agg(EventF1_mean=("EventF1", "mean"), EventF1_std=("EventF1", "std"))
    )

    fig, axes = plt.subplots(
        1,
        len(targets),
        figsize=(4.5 * len(targets), 4.0),
        constrained_layout=True,
    )

    if len(targets) == 1:
        axes = [axes]

    for i, target in enumerate(targets):
        ax = axes[i]
        sub = summary[summary["Target"] == target]

        for model in models:
            sm = sub[sub["Model"] == model].set_index("PredLen").reindex(pred_lens)
            x = np.asarray(pred_lens, dtype=float)
            y = sm["EventF1_mean"].to_numpy(dtype=float)
            s = sm["EventF1_std"].fillna(0.0).to_numpy(dtype=float)

            ax.plot(
                x,
                y,
                label=model,
                color=colors[model],
                linestyle=linestyles[model],
                marker=markers[model],
                markerfacecolor="white",
                markeredgewidth=0.8,
            )
            ax.fill_between(x, y - s, y + s, color=colors[model], alpha=0.08, linewidth=0)

        ax.set_title(f"({chr(ord('a') + i)}) {short_target_name(target)}", fontweight="bold")
        ax.set_xlabel("Forecast horizon (steps)")
        ax.set_ylabel("High-event F1")
        ax.set_ylim(0, 1.05)
        ax.set_xticks(pred_lens)
        ax.grid(axis="y", linestyle="--", linewidth=0.5, alpha=0.35)

    for ext in ["png", "pdf", "svg"]:
        fig.savefig(os.path.join(save_dir, f"n2o_2min_high_event_f1.{ext}"))

    plt.close(fig)


def plot_runtime_efficiency(runtime_df, models, save_dir):
    if runtime_df is None or runtime_df.empty:
        return

    set_journal_style()

    metrics = [
        ("AvgEpochTimeSec", "Avg. epoch time (s)"),
        ("TotalFitTimeSec", "Total fit time (s)"),
        ("InferenceLatencyMsPerWindow", "Inference latency (ms/window)"),
        ("InferenceThroughputWindowsPerSec", "Throughput (windows/s)"),
        ("PeakGpuMemoryMB", "Peak GPU memory (MB)"),
        ("TrainableParams", "Trainable parameters"),
    ]

    colors, _, _ = visual_style()
    fig, axes = plt.subplots(2, 3, figsize=(11, 7), constrained_layout=True)
    axes = axes.reshape(-1)
    x = np.arange(len(models))

    for i, (metric, ylabel) in enumerate(metrics):
        ax = axes[i]
        means = runtime_df.groupby("Model")[metric].mean().reindex(models).values.astype(float)
        stds = runtime_df.groupby("Model")[metric].std().reindex(models).values.astype(float)

        if np.all(~np.isfinite(means)):
            ax.text(0.5, 0.5, "Not available", ha="center", va="center", transform=ax.transAxes)
            ax.set_xticks([])
            ax.set_yticks([])
            continue

        ax.bar(
            x,
            means,
            yerr=stds,
            capsize=2.5,
            width=0.72,
            color=[colors[m] for m in models],
            edgecolor="black",
            linewidth=0.8,
            zorder=3,
        )

        ax.set_title(f"({chr(ord('a') + i)}) {ylabel}", fontweight="bold")
        ax.set_ylabel(ylabel)
        ax.set_xticks(x)
        ax.set_xticklabels(models, rotation=30, ha="right")
        ax.grid(axis="y", linestyle="--", linewidth=0.5, alpha=0.35, zorder=0)

        if metric == "TrainableParams":
            ax.yaxis.set_major_formatter(
                mpl.ticker.FuncFormatter(
                    lambda v, pos: f"{v / 1e3:.0f}K" if v < 1e6 else f"{v / 1e6:.1f}M"
                )
            )

    for ext in ["png", "pdf", "svg"]:
        fig.savefig(os.path.join(save_dir, f"n2o_2min_runtime_efficiency.{ext}"))

    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(
        description="External generalization experiment on public 2-min N2O WWTP data."
    )

    parser.add_argument("--data_path", type=str, default= r"D:\我的论文-污水处理\sci\wastewater-prediction\data\processed\n2o_2min_half_year.csv")
    parser.add_argument("--output_dir", type=str, default="outputs/n2o_2min_external_generalization")
    parser.add_argument("--targets", nargs="+", default=[DEFAULT_N2O_TARGET])
    parser.add_argument(
        "--models",
        nargs="+",
        default=[
            "Persistence",
            "SeasonalNaive",
            "TSF-Resonator",
            "MixLinear",
            "DLinear",
            "SparseTSF",
            "PatchTST",
            "iTransformer",

        ],
    )
    parser.add_argument("--seq_len", type=int, default=96)
    parser.add_argument("--pred_lens", nargs="+", type=int, default=[12, 24, 48, 96])
    parser.add_argument("--sample_minutes", type=int, default=2)

    parser.add_argument(
        "--seasonal_lag",
        type=int,
        default=24,
        help="Lag steps for SeasonalNaive. With 2-min data, 48 means 96 minutes.",
    )

    parser.add_argument("--num_seeds", type=int, default=5)
    parser.add_argument("--start_seed", type=int, default=2021)
    parser.add_argument("--seeds", type=str, default=None)

    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--runtime_batch_size", type=int, default=64)
    parser.add_argument("--runtime_repeats", type=int, default=5)

    parser.add_argument("--learning_rate", type=float, default=5e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)

    parser.add_argument(
        "--feature_mode",
        type=str,
        default="all",
        choices=["all", "topk"],
        help="all: use all usable numeric variables as input; topk: use correlation Top-K.",
    )
    parser.add_argument("--feature_selection_k", type=int, default=25)
    parser.add_argument(
        "--disable_time_features",
        action="store_true",
        help="Disable engineered calendar/time figures.",
    )
    parser.add_argument(
        "--disable_target_lag_features",
        action="store_true",
        help="Disable engineered target lag/rolling figures.",
    )
    parser.add_argument(
        "--no_correlation_plot",
        action="store_true",
        help="Skip correlation heatmap generation.",
    )
    parser.add_argument(
        "--max_corr_plot_features",
        type=int,
        default=60,
        help="Maximum number of variables shown in the correlation heatmap only.",
    )
    parser.add_argument("--max_feature_missing_ratio", type=float, default=0.30)
    parser.add_argument("--high_event_quantile", type=float, default=0.90)
    parser.add_argument("--train_ratio", type=float, default=0.70)
    parser.add_argument("--val_ratio", type=float, default=0.10)

    parser.add_argument("--deterministic", action="store_true")
    parser.add_argument(
        "--dry_run",
        action="store_true",
        help="Quick logic check: one seed, first pred_len, Persistence/DLinear/TSF-Resonator, one epoch, two batches.",
    )

    args = parser.parse_args()

    if args.dry_run:
        args.num_seeds = 1
        args.seeds = str(args.start_seed)
        args.epochs = 1
        args.patience = 1
        args.models = ["Persistence", "DLinear", "TSF-Resonator"]
        args.pred_lens = [args.pred_lens[0]]

    seeds = parse_seed_list(args.seeds, args.num_seeds, args.start_seed)

    cfg = GlobalConfig()
    cfg.data_path = args.data_path
    cfg.output_dir = args.output_dir
    cfg.seq_len = args.seq_len
    cfg.sample_minutes = args.sample_minutes

    cfg.batch_size = args.batch_size
    cfg.epochs = args.epochs
    cfg.patience = args.patience
    cfg.learning_rate = args.learning_rate
    cfg.weight_decay = args.weight_decay

    cfg.loss_name = "huber"
    cfg.huber_delta = 1.0

    cfg.train_ratio = args.train_ratio
    cfg.val_ratio = args.val_ratio

    # Feature mode:
    #   all  -> use all usable numeric variables as input channels.
    #   topk -> recover the old correlation Top-K feature selection.
    cfg.feature_mode = args.feature_mode
    cfg.feature_selection_k = args.feature_selection_k
    cfg.max_feature_missing_ratio = args.max_feature_missing_ratio
    cfg.high_event_quantile = args.high_event_quantile

    cfg.max_interpolation_steps = int(round(3 * 60 / args.sample_minutes))
    cfg.add_time_features = not args.disable_time_features
    cfg.add_target_lag_features = not args.disable_target_lag_features
    cfg.plot_correlation = not args.no_correlation_plot
    cfg.max_corr_plot_features = args.max_corr_plot_features

    cfg.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cfg.runtime_batch_size = args.runtime_batch_size
    cfg.runtime_warmup_batches = 5
    cfg.runtime_repeats = args.runtime_repeats

    cfg.max_train_batches = 2 if args.dry_run else None
    cfg.max_val_batches = 2 if args.dry_run else None

    targets = args.targets
    models = args.models
    pred_lens = args.pred_lens

    unknown = [m for m in models if m not in TRAINABLE_MODELS + NAIVE_MODELS]
    if unknown:
        raise ValueError(f"Unknown models: {unknown}")

    fig_dir = os.path.join(cfg.output_dir, "figures")
    log_dir = os.path.join(cfg.output_dir, "logs")
    pred_dir = os.path.join(cfg.output_dir, "predictions")
    ckpt_dir = os.path.join(cfg.output_dir, "checkpoints")

    for d in [fig_dir, log_dir, pred_dir, ckpt_dir]:
        os.makedirs(d, exist_ok=True)

    print("=" * 100)
    print("External generalization experiment on public 2-min N2O WWTP data")
    print(f"Data path: {cfg.data_path}")
    print(f"Output dir: {cfg.output_dir}")
    print(f"Sample interval: {cfg.sample_minutes} min")
    print(f"Seq_len: {cfg.seq_len} steps = {cfg.seq_len * cfg.sample_minutes} min")
    print(f"Pred_lens: {pred_lens}")
    print(f"Pred horizons in minutes: {[p * cfg.sample_minutes for p in pred_lens]}")
    print(f"Seeds: {seeds}")
    print(f"Targets: {targets}")
    print(f"Models: {models}")
    print(f"Feature mode: {cfg.feature_mode}")
    print(f"Add time figures: {cfg.add_time_features}")
    print(f"Add target lag figures: {cfg.add_target_lag_features}")
    print(f"Device: {cfg.device}")
    print("=" * 100)

    overall_rows = []
    stepwise_rows = []
    high_rows = []
    loss_rows = []
    runtime_rows = []

    for target in targets:
        cfg.target_col = target

        print(f"\n{'=' * 90}")
        print(f"Target: {target}")
        print(f"{'=' * 90}")

        for pred_len in pred_lens:
            cfg.pred_len = pred_len

            print(f"\n--- Prediction horizon: {pred_len} steps = {pred_len * cfg.sample_minutes} min ---")

            processor = N2O2MinDataProcessor(cfg)
            data_scaled = processor.prepare_data()

            target_idx = processor.target_idx
            num_vars = data_scaled.shape[1]
            high_threshold = processor.target_high_threshold

            train_len = int(len(data_scaled) * cfg.train_ratio)
            val_len = int(len(data_scaled) * cfg.val_ratio)

            train_data = data_scaled[:train_len]
            val_data = data_scaled[train_len:train_len + val_len]
            test_data = data_scaled[train_len + val_len:]

            train_set = TimeSeriesDataset(train_data, cfg.seq_len, cfg.pred_len)
            val_set = TimeSeriesDataset(val_data, cfg.seq_len, cfg.pred_len)
            test_set = TimeSeriesDataset(test_data, cfg.seq_len, cfg.pred_len)

            print(f"Data tensor shape: {data_scaled.shape}")
            print(f"Input figures: {num_vars}")
            print(f"Feature mode: {getattr(cfg, 'feature_mode', 'all')}")
            print(f"Target index: {target_idx}")
            print(f"High-event threshold: {high_threshold:.6f}")
            print(f"Splits: train={len(train_set)}, val={len(val_set)}, test={len(test_set)}")

            preflight_model_forward_check(
                models=models,
                cfg=cfg,
                num_vars=num_vars,
                target_idx=target_idx,
                device=cfg.device,
            )
            print("Preflight model forward check passed.")

            for seed in seeds:
                print(f"\n>>> Seed: {seed}")
                set_seed(seed, deterministic=args.deterministic)

                gen = torch.Generator()
                gen.manual_seed(seed)

                train_loader = DataLoader(
                    train_set,
                    cfg.batch_size,
                    shuffle=True,
                    drop_last=True,
                    generator=gen,
                )
                val_loader = DataLoader(val_set, cfg.batch_size, shuffle=False)
                test_loader = DataLoader(test_set, batch_size=1, shuffle=False)
                runtime_loader = DataLoader(
                    test_set,
                    batch_size=cfg.runtime_batch_size,
                    shuffle=False,
                    drop_last=False,
                )

                for model_name in models:
                    print(
                        f"\nModel: {model_name} | "
                        f"target={short_target_name(target)} | "
                        f"pred={pred_len} | seed={seed}"
                    )

                    if model_name in NAIVE_MODELS:
                        overall, stepwise, high, inv_pred, inv_act, runtime = evaluate_naive_baseline(
                            test_loader=test_loader,
                            runtime_loader=runtime_loader,
                            cfg=cfg,
                            target_idx=target_idx,
                            num_vars=num_vars,
                            scaler=processor.scaler,
                            baseline_name=model_name,
                            high_threshold=high_threshold,
                            seasonal_lag=args.seasonal_lag,
                        )
                        history = None
                    else:
                        set_seed(seed, deterministic=args.deterministic)
                        model = build_model(model_name, cfg, num_vars).to(cfg.device)

                        overall, stepwise, high, inv_pred, inv_act, history, runtime = train_and_evaluate(
                            model=model,
                            train_loader=train_loader,
                            val_loader=val_loader,
                            test_loader=test_loader,
                            runtime_loader=runtime_loader,
                            cfg=cfg,
                            device=cfg.device,
                            target_idx=target_idx,
                            num_vars=num_vars,
                            scaler=processor.scaler,
                            model_name=model_name,
                            high_threshold=high_threshold,
                            seed=seed,
                        )

                    overall_rows.append({
                        "Seed": seed,
                        "Target": target,
                        "PredLen": pred_len,
                        "PredMinutes": pred_len * cfg.sample_minutes,
                        "Model": model_name,
                        "MSE": overall["MSE"],
                        "MAE": overall["MAE"],
                        "RMSE": overall["RMSE"],
                        "R2": overall["R2"],
                    })

                    high_row = {
                        "Seed": seed,
                        "Target": target,
                        "PredLen": pred_len,
                        "PredMinutes": pred_len * cfg.sample_minutes,
                        "Model": model_name,
                    }
                    high_row.update(high)
                    high_rows.append(high_row)

                    stepwise = stepwise.copy()
                    stepwise.insert(0, "Seed", seed)
                    stepwise.insert(1, "Target", target)
                    stepwise.insert(2, "PredLen", pred_len)
                    stepwise.insert(3, "PredMinutes", pred_len * cfg.sample_minutes)
                    stepwise.insert(4, "Model", model_name)
                    stepwise_rows.append(stepwise)

                    if history is not None and pred_len == max(pred_lens):
                        for epoch_idx in range(len(history["train_loss"])):
                            loss_rows.append({
                                "Seed": seed,
                                "Target": target,
                                "PredLen": pred_len,
                                "PredMinutes": pred_len * cfg.sample_minutes,
                                "Model": model_name,
                                "Epoch": epoch_idx + 1,
                                "TrainLoss": history["train_loss"][epoch_idx],
                                "ValLoss": history["val_loss"][epoch_idx],
                                "EpochTimeSec": history["epoch_time_sec"][epoch_idx],
                                "TrainEpochTimeSec": history["train_epoch_time_sec"][epoch_idx],
                                "ValEpochTimeSec": history["val_epoch_time_sec"][epoch_idx],
                            })

                    if pred_len == max(pred_lens):
                        runtime_row = {
                            "Seed": seed,
                            "Target": target,
                            "PredLen": pred_len,
                            "PredMinutes": pred_len * cfg.sample_minutes,
                            "Model": model_name,
                            "Device": str(cfg.device),
                            "SeqLen": cfg.seq_len,
                            "SeqMinutes": cfg.seq_len * cfg.sample_minutes,
                            "TrainBatchSize": cfg.batch_size,
                            "RuntimeBatchSize": cfg.runtime_batch_size,
                        }
                        runtime_row.update(runtime)
                        runtime_rows.append(runtime_row)

                    np.savez_compressed(
                        os.path.join(
                            pred_dir,
                            f"n2o_2min_predictions_{safe_name(target)}_{model_name}_pred{pred_len}_seed{seed}.npz",
                        ),
                        pred=inv_pred,
                        actual=inv_act,
                        target=target,
                        model=model_name,
                        seed=seed,
                        seq_len=cfg.seq_len,
                        pred_len=cfg.pred_len,
                        sample_minutes=cfg.sample_minutes,
                        high_threshold=high_threshold,
                    )

                    print(
                        f"Overall | MSE={overall['MSE']:.6f}, "
                        f"MAE={overall['MAE']:.6f}, "
                        f"RMSE={overall['RMSE']:.6f}, "
                        f"R2={overall['R2']:.6f}, "
                        f"HighF1={high['EventF1']:.4f}"
                    )

    overall_df = pd.DataFrame(overall_rows)
    stepwise_df = pd.concat(stepwise_rows, ignore_index=True) if stepwise_rows else pd.DataFrame()
    high_df = pd.DataFrame(high_rows)
    loss_df = pd.DataFrame(loss_rows) if loss_rows else pd.DataFrame()
    runtime_df = pd.DataFrame(runtime_rows) if runtime_rows else pd.DataFrame()

    overall_df.to_csv(
        os.path.join(log_dir, "n2o_2min_overall_metrics_by_seed.csv"),
        index=False,
        float_format="%.10f",
    )
    stepwise_df.to_csv(
        os.path.join(log_dir, "n2o_2min_stepwise_metrics_by_seed.csv"),
        index=False,
        float_format="%.10f",
    )
    high_df.to_csv(
        os.path.join(log_dir, "n2o_2min_high_event_metrics_by_seed.csv"),
        index=False,
        float_format="%.10f",
    )

    if not loss_df.empty:
        loss_df.to_csv(
            os.path.join(log_dir, "n2o_2min_loss_history_by_seed.csv"),
            index=False,
            float_format="%.10f",
        )

    if not runtime_df.empty:
        runtime_df.to_csv(
            os.path.join(log_dir, "n2o_2min_runtime_efficiency_by_seed.csv"),
            index=False,
            float_format="%.10f",
        )

    metric_cols = ["MSE", "MAE", "RMSE", "R2"]
    overall_summary = summarize_repeated_runs(
        overall_df,
        group_cols=["Target", "PredLen", "PredMinutes", "Model"],
        metric_cols=metric_cols,
    )
    overall_summary.to_csv(
        os.path.join(log_dir, "n2o_2min_overall_summary_mean_std_ci95.csv"),
        index=False,
        float_format="%.10f",
    )

    high_metric_cols = [
        "High_MSE",
        "High_MAE",
        "High_RMSE",
        "High_R2",
        "EventPrecision",
        "EventRecall",
        "EventF1",
    ]
    high_summary = summarize_repeated_runs(
        high_df,
        group_cols=["Target", "PredLen", "PredMinutes", "Model"],
        metric_cols=high_metric_cols,
    )
    high_summary.to_csv(
        os.path.join(log_dir, "n2o_2min_high_event_summary_mean_std_ci95.csv"),
        index=False,
        float_format="%.10f",
    )

    if not stepwise_df.empty:
        stepwise_summary = summarize_repeated_runs(
            stepwise_df,
            group_cols=["Target", "PredLen", "PredMinutes", "Model", "Step"],
            metric_cols=metric_cols,
        )
        stepwise_summary.to_csv(
            os.path.join(log_dir, "n2o_2min_stepwise_summary_mean_std_ci95.csv"),
            index=False,
            float_format="%.10f",
        )

    for metric in metric_cols:
        mean_mat = overall_summary.pivot_table(
            index=["Target", "PredLen", "PredMinutes"],
            columns="Model",
            values=f"{metric}_mean",
            aggfunc="first",
        )
        std_mat = overall_summary.pivot_table(
            index=["Target", "PredLen", "PredMinutes"],
            columns="Model",
            values=f"{metric}_std",
            aggfunc="first",
        )
        ci_mat = overall_summary.pivot_table(
            index=["Target", "PredLen", "PredMinutes"],
            columns="Model",
            values=f"{metric}_ci95",
            aggfunc="first",
        )

        mean_mat.to_csv(
            os.path.join(log_dir, f"n2o_2min_{metric.lower()}_mean_matrix.csv"),
            float_format="%.10f",
        )
        std_mat.to_csv(
            os.path.join(log_dir, f"n2o_2min_{metric.lower()}_std_matrix.csv"),
            float_format="%.10f",
        )
        ci_mat.to_csv(
            os.path.join(log_dir, f"n2o_2min_{metric.lower()}_ci95_matrix.csv"),
            float_format="%.10f",
        )

    export_latex_ready_metric_tables(overall_summary, log_dir, metrics=metric_cols)

    pairwise_df = pairwise_tests_vs_reference(
        overall_df,
        reference_model="TSF-Resonator",
        metrics=metric_cols,
    )
    if not pairwise_df.empty:
        pairwise_df.to_csv(
            os.path.join(log_dir, "n2o_2min_pairwise_tests_vs_tsf_resonator_holm.csv"),
            index=False,
            float_format="%.10f",
        )

    if not runtime_df.empty:
        runtime_numeric = [
            "TotalParams",
            "TrainableParams",
            "ActualEpochs",
            "BestEpoch",
            "TotalFitTimeSec",
            "AvgEpochTimeSec",
            "AvgTrainEpochTimeSec",
            "AvgValEpochTimeSec",
            "InferenceLatencyMsPerWindow",
            "InferenceLatencyMsPerBatch",
            "InferenceThroughputWindowsPerSec",
            "PeakGpuMemoryMB",
        ]
        runtime_summary = runtime_df.groupby("Model")[runtime_numeric].agg(["mean", "std"]).reindex(models)
        runtime_summary.to_csv(
            os.path.join(log_dir, "n2o_2min_runtime_efficiency_summary_mean_std.csv"),
            float_format="%.10f",
        )

    plot_overall_mse(overall_df, targets, models, pred_lens, fig_dir)
    plot_high_event_f1(high_df, targets, models, pred_lens, fig_dir)

    if not runtime_df.empty:
        plot_runtime_efficiency(runtime_df, models, fig_dir)

    print(f"\nAll N2O 2-min external generalization results saved under: {cfg.output_dir}")
    print("Key output files:")
    print(os.path.join(log_dir, "n2o_2min_overall_metrics_by_seed.csv"))
    print(os.path.join(log_dir, "n2o_2min_overall_summary_mean_std_ci95.csv"))
    print(os.path.join(log_dir, "n2o_2min_high_event_summary_mean_std_ci95.csv"))
    print(os.path.join(log_dir, "n2o_2min_pairwise_tests_vs_tsf_resonator_holm.csv"))
    print(os.path.join(fig_dir, "n2o_2min_overall_mse_multi_horizon.[png|pdf|svg]"))
    print(os.path.join(fig_dir, "n2o_2min_high_event_f1.[png|pdf|svg]"))


if __name__ == "__main__":
    main()
