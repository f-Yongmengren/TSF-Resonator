import torch
import torch.nn as nn
import torch.nn.functional as F

import torch
import torch.nn as nn
import torch.nn.functional as F
from src.layers import RevIN, AdaptiveMultiScaleTrend, LowRankSpectralFilter


class TSFResonator(nn.Module):
    """时频共振网络 —— 消融优化轻量版"""
    def __init__(self, num_vars, seq_len, pred_len,
                 trend_scales=[3, 7, 15],
                 d_res=16,
                 dropout=0.1):
        super().__init__()
        self.num_vars = num_vars
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.internal_len = seq_len
        self.target_idx = -1

        self.revin = RevIN(num_vars, affine=True)

        # ---- 时域分支 ----
        self.trend_extractor = AdaptiveMultiScaleTrend(kernel_sizes=trend_scales)
        self.conv_seasonal = nn.Conv1d(1, d_res, kernel_size=3, padding=1, bias=False)
        self.conv_trend    = nn.Conv1d(1, d_res, kernel_size=3, padding=1, bias=False)
        self.pool_global = nn.AdaptiveAvgPool1d(1)

        # 近期局部融合权重（可学习）
        self.w_seasonal_local = nn.Parameter(torch.tensor(0.3))
        self.w_trend_local    = nn.Parameter(torch.tensor(0.3))

        # ---- 频域分支 (静态低秩) ----
        self.freq_filter = LowRankSpectralFilter(self.internal_len, nz=2, dropout=dropout)
        self.conv_freq = nn.Conv1d(1, d_res, kernel_size=3, padding=1, bias=False)
        self.pool_freq = nn.AdaptiveAvgPool1d(1)

        # ---- 简单融合 ----
        self.alpha = nn.Parameter(torch.tensor(0.5))

        # ---- 预测头 ----
        self.projector = nn.Linear(d_res, pred_len)

    def forward(self, x):
        B, L, N = x.shape

        x_norm = self.revin(x, 'norm')
        x_unified = x_norm

        x_ci = x_unified.permute(0, 2, 1).reshape(B * N, 1, self.internal_len)

        # 时域分解
        trend, seasonal = self.trend_extractor(x_ci)

        # 季节项：全局+局部
        s_feat = self.conv_seasonal(seasonal)
        s_global = self.pool_global(s_feat).squeeze(-1)
        s_local  = s_feat[:, :, -8:].mean(dim=-1)
        w_s = torch.sigmoid(self.w_seasonal_local)
        s_out = (1 - w_s) * s_global + w_s * s_local

        # 趋势项：全局+局部
        t_feat = self.conv_trend(trend)
        t_global = self.pool_global(t_feat).squeeze(-1)
        t_local  = t_feat[:, :, -8:].mean(dim=-1)
        w_t = torch.sigmoid(self.w_trend_local)
        t_out = (1 - w_t) * t_global + w_t * t_local

        h_t = s_out + t_out

        # 频域静态滤波（含残差）
        x_for_freq = x_unified.permute(0, 2, 1)
        x_freq = self.freq_filter(x_for_freq)
        x_freq = x_freq.permute(0, 2, 1).reshape(B * N, 1, self.internal_len)
        f_feat = self.conv_freq(x_freq)
        h_f = self.pool_freq(f_feat).squeeze(-1)

        # 朴素加权融合
        alpha = torch.sigmoid(self.alpha)
        h_res = alpha * h_t + (1 - alpha) * h_f

        # 预测
        pred_ci = self.projector(h_res)
        pred = pred_ci.reshape(B, N, self.pred_len).permute(0, 2, 1)

        pred = self.revin(pred, 'denorm')

        # Output mode:
        # - target_idx is None: return all variables, shape [B, pred_len, N]
        # - target_idx >= 0: return one specified target variable, shape [B, pred_len]
        # - target_idx < 0: backward-compatible single-target mode, return the last variable
        if self.target_idx is None:
            return pred

        if isinstance(self.target_idx, int) and self.target_idx >= 0:
            return pred[:, :, self.target_idx]

        return pred[:, :, -1]


