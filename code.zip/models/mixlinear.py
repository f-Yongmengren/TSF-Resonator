import torch
import torch.nn as nn
from src.layers import PositionalEmbedding
import math
import torch.nn.functional as F


class RevIN(nn.Module):
    """Reversible Instance Normalization"""

    def __init__(self, num_features, eps=1e-5, affine=True):
        super().__init__()
        self.num_features = num_features
        self.eps = eps
        self.affine = affine
        if self.affine:
            self._init_params()

    def _init_params(self):
        self.affine_weight = nn.Parameter(torch.ones(self.num_features))
        self.affine_bias = nn.Parameter(torch.zeros(self.num_features))

    def forward(self, x, mode: str):
        if mode == 'norm':
            self._get_statistics(x)
            x = self._normalize(x)
        elif mode == 'denorm':
            x = self._denormalize(x)
        return x

    def _get_statistics(self, x):
        dim2reduce = 1
        self.mean = torch.mean(x, dim=dim2reduce, keepdim=True).detach()
        self.stdev = torch.sqrt(
            torch.var(x, dim=dim2reduce, keepdim=True, unbiased=False) + self.eps
        ).detach()

    def _normalize(self, x):
        x = x - self.mean
        x = x / self.stdev
        if self.affine:
            x = x * self.affine_weight + self.affine_bias
        return x

    def _denormalize(self, x):
        if self.affine:
            x = (x - self.affine_bias) / (self.affine_weight + self.eps)
        x = x * self.stdev
        x = x + self.mean
        return x


class Model(nn.Module):
    def __init__(self, configs):
        super(Model, self).__init__()

        # get parameters
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.enc_in = configs.enc_in
        self.period_len = configs.period_len

        self.kernel = self.period_len
        self.lpf = configs.lpf
        # 实际可用的低频分量数（不能超过 seg_num_x，即 FFT 长度）
        self.seg_num_x = math.ceil(self.seq_len / self.period_len)
        self.seg_num_y = math.ceil(self.pred_len / self.period_len)
        self.actual_lpf = min(self.lpf, self.seg_num_x)

        self.alpha = configs.alpha

        self.sqrt_seg_num_x = math.ceil(math.sqrt(self.seq_len / self.period_len))
        self.sqrt_seg_num_y = math.ceil(math.sqrt(self.pred_len / self.period_len))

        # RevIN 可逆实例归一化
        self.revin = RevIN(num_features=self.enc_in, affine=True)

        # TLinear
        self.TLinear1 = nn.Linear(self.sqrt_seg_num_x, self.sqrt_seg_num_y, bias=False)
        self.TLinear2 = nn.Linear(self.sqrt_seg_num_x, self.sqrt_seg_num_y, bias=False)

        self.conv1d = nn.Conv1d(in_channels=1, out_channels=1, kernel_size=self.kernel + 1,
                                stride=1, padding=int(self.kernel / 2),
                                padding_mode="zeros", bias=False)

        # FLinear – 使用实际低频数 actual_lpf
        self.FLinear1 = nn.Linear(self.actual_lpf, 2, bias=False).to(torch.cfloat)
        self.FLinear2 = nn.Linear(2, self.seg_num_y, bias=False).to(torch.cfloat)

    def forward(self, x):
        batch_size = x.shape[0]
        # x: [B, seq_len, enc_in]

        # 1. RevIN 归一化
        x = self.revin(x, 'norm')  # [B, seq_len, enc_in]

        # 2. 转置为 [B, enc_in, seq_len] 并聚合
        x = x.permute(0, 2, 1)  # [B, enc_in, seq_len]
        x = self.conv1d(x.reshape(-1, 1, self.seq_len)).reshape(
            -1, self.enc_in, self.seq_len) + x  # 跳跃连接

        # 3. 分段重塑：-> [B, enc_in, period_len, seg_num_x]
        x = x.reshape(batch_size, self.enc_in, -1, self.period_len).permute(0, 1, 3, 2)

        # ---- 时域通路 ----
        # Padding 为完全平方数，以便进行方形矩阵操作
        x_o = F.pad(x, (0, self.sqrt_seg_num_x ** 2 - x.shape[-1], 0, 0, 0, 0))
        x_o = x_o.reshape(batch_size, self.enc_in, self.period_len,
                          self.sqrt_seg_num_x, self.sqrt_seg_num_x)
        x_o = self.TLinear1(x_o).permute(0, 1, 2, 4, 3)
        x_t = self.TLinear2(x_o).permute(0, 1, 2, 4, 3)
        # 恢复为 [B, enc_in, -1] 再转回 [B, -1, enc_in]
        x_t = (x_t.reshape(batch_size, self.enc_in, self.period_len, -1)
               .permute(0, 1, 3, 2)
               .reshape(batch_size, self.enc_in, -1)
               .permute(0, 2, 1))  # [B, seq_len?, enc_in]

        # ---- 频域通路 ----
        # 截取前 actual_lpf 个低频分量（避免超出 actual_lpf）
        x_fft = torch.fft.fft(x, dim=3)[:, :, :, :self.actual_lpf]
        x_fft = self.FLinear1(x_fft)
        x_fft = self.FLinear2(x_fft).reshape(batch_size, self.enc_in, self.period_len, -1)
        x_rfft = torch.fft.ifft(x_fft, dim=3).float()
        x_f = (x_rfft.permute(0, 1, 3, 2)
               .reshape(batch_size, self.enc_in, -1)
               .permute(0, 2, 1))  # [B, -1, enc_in]

        # ---- 融合（使用截断到 pred_len） ----
        pred = (x_t[:, :self.pred_len, :] * self.alpha +
                x_f[:, :self.pred_len, :] * (1 - self.alpha))  # [B, pred_len, enc_in]

        # 4. RevIN 反归一化
        pred = self.revin(pred, 'denorm')  # [B, pred_len, enc_in]

        return pred