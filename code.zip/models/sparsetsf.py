import torch
import torch.nn as nn


class RevIN(nn.Module):
    """Reversible Instance Normalization"""
    def __init__(self, num_features, eps=1e-5, affine=True):
        super().__init__()
        self.num_features = num_features
        self.eps = eps
        self.affine = affine
        if self.affine:
            self._init_params()

    def _init_params(self):
        self.affine_weight = nn.Parameter(torch.ones(self.num_features))
        self.affine_bias   = nn.Parameter(torch.zeros(self.num_features))

    def forward(self, x, mode: str):
        if mode == 'norm':
            self._get_statistics(x)
            x = self._normalize(x)
        elif mode == 'denorm':
            x = self._denormalize(x)
        return x

    def _get_statistics(self, x):
        dim2reduce = 1
        self.mean = torch.mean(x, dim=dim2reduce, keepdim=True).detach()
        self.stdev = torch.sqrt(
            torch.var(x, dim=dim2reduce, keepdim=True, unbiased=False) + self.eps
        ).detach()

    def _normalize(self, x):
        x = x - self.mean
        x = x / self.stdev
        if self.affine:
            x = x * self.affine_weight + self.affine_bias
        return x

    def _denormalize(self, x):
        if self.affine:
            x = (x - self.affine_bias) / (self.affine_weight + self.eps)
        x = x * self.stdev
        x = x + self.mean
        return x


class SparseTSF(nn.Module):
    """
    SparseTSF baseline with RevIN for fair comparison.
    Original: "SparseTSF: Modeling Long-term Time Series Forecasting with 1k Parameters"
    """
    def __init__(self, num_vars, seq_len, pred_len, w=24):
        super().__init__()
        self.num_vars = num_vars
        self.seq_len  = seq_len
        self.pred_len = pred_len
        self.w = w
        self.n = seq_len // w          # downsampled length
        self.m = pred_len // w

        # ---- RevIN 可逆实例归一化 ----
        self.revin = RevIN(num_features=num_vars, eps=1e-5, affine=True)

        # 1D convolution for sliding aggregation
        kernel_size = 2 * (w // 2) + 1
        self.conv_agg = nn.Conv1d(1, 1, kernel_size,
                                  padding=kernel_size // 2, bias=False)

        # Shared linear layer across all w subsequences
        self.linear = nn.Linear(self.n, self.m, bias=False)

    def forward(self, x):
        # x: [B, L, C]
        B, L, C = x.shape

        # 1. RevIN 归一化（替代原手动减均值）
        x_norm = self.revin(x, 'norm')                   # [B, L, C]

        # 2. 通道独立处理：展平通道至 batch 维度
        x_flat = x_norm.permute(0, 2, 1).reshape(B * C, 1, L)  # [B*C, 1, L]

        # 3. 滑动聚合
        x_agg = self.conv_agg(x_flat)
        x_combined = x_flat + x_agg                     # [B*C, 1, L]

        # 4. 降采样 -> 线性预测 -> 上采样
        x_down = x_combined.view(B * C, self.n, self.w).transpose(1, 2)   # [B*C, w, n]
        pred_down = self.linear(x_down)                                     # [B*C, w, m]
        pred_flat = pred_down.transpose(1, 2).reshape(B * C, self.pred_len) # [B*C, H]

        # 5.  [B, H, C]
        pred = pred_flat.view(B, C, self.pred_len).permute(0, 2, 1)        # [B, H, C]

        # 6. RevIN 反归一化
        pred = self.revin(pred, 'denorm')

        return pred